import { RequestController } from "./RequestController";

type Method = "POST" | "PUT";

interface SubmitHandlerConfig {
  e: React.FormEvent;
  entityName: string; // e.g., 'courses', 'groups', 'results'
  item?: { id: string | number }; // Optional if updating
  data: any; // FormData
  onSuccess: () => void;
  onOpenChange: (open: boolean) => void;
  setLoading: (loading: boolean) => void;
  toast: (options: { title: string; variant?: "default" | "destructive" }) => void;
  t: (key: string) => string;
  customPaths?: {
    create?: string;
    update?: (id: string | number) => string;
  };
  customSuccessMessages?: {
    created?: string;
    updated?: string;
  };
}

const apiRequest = async (
  url: string,
  method: Method,
  formData: FormData,
  onSuccess: (messageKey: "created" | "updated" | "custom") => void,
  onError: (error: any) => void
) => {
  try {
    const response = await RequestController(url, method, formData);

    if (response.status === 201) {
      onSuccess("created");
    } else if (response.status === 200) {
      onSuccess("updated");
    } else {
      throw new Error("Unexpected status code");
    }
  } catch (error) {
    onError(error);
  }
};

const handleFormSubmit = ({
  e,
  entityName,
  item,
  data,
  onSuccess,
  onOpenChange,
  setLoading,
  toast,
  t,
  customPaths = {},
  customSuccessMessages = {}
}: SubmitHandlerConfig) => {
  e.preventDefault();
  setLoading(true);

  const method: Method = item ? "PUT" : "POST";
  // Determine URL
  const url = item
    ? customPaths.update?.(item.id) ?? `/${entityName}/update-${entityName.slice(0, -1)}/${item.id}`
    : customPaths.create ?? `/${entityName}/add-${entityName.slice(0, -1)}`;

  const handleSuccess = (action: "created" | "updated" | "custom") => {
    const message =
      (action === "created" && customSuccessMessages.created) ||
      (action === "updated" && customSuccessMessages.updated) ||
      t(`${entityName}.${action}`);

    toast({title: message, variant: "default"});
    onSuccess();
    onOpenChange(false);
  };

  const handleError = (error: any) => {
    console.error(error);
    toast({ title: t("common.error"), variant: "destructive" });
  };

  apiRequest(url, method, data, handleSuccess, handleError).finally(() =>
    setLoading(false)
  );
};

export default handleFormSubmit;
