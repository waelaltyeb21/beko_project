import AxiosConfig from "@/config/AxiosConfig";
import { AxiosRequestConfig, AxiosResponse, Method } from "axios";

export interface RequestResult<T = any> {
  data?: T;
  status?: number;
  headers?: Record<string, any>;
  error?: string;
}

/**
 * A reusable Axios request controller with TypeScript typing.
 */
export const RequestController = async <T = any>(
  url: string,
  method: Method = "GET",
  data: Record<string, any> = {},
  headers: Record<string, any> = {},
  abortSignal: AbortSignal | null = null
): Promise<RequestResult<T>> => {
  try {
    if (!url) throw new Error("URL is a required parameter");

    const config: AxiosRequestConfig = {
      url,
      method,
      data,
      headers,
      signal: abortSignal || undefined,
    };

    const response: AxiosResponse<T> = await AxiosConfig(config);

    if (response.status === 200 || response.status === 201) {
      return {
        data: response.data,
        status: response.status,
        headers: response.headers,
      };
    }

    throw new Error(`Request failed with status ${response.status}`);
  } catch (error: any) {
    return {
      error: error?.message || "An unknown error occurred",
      status: error?.response?.status,
      data: error?.response?.data,
    };
  }
};
