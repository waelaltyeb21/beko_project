export const NumberFormat = (num:number) => {
  const number = Intl.NumberFormat("en-US").format(Number(num));
  return number;
};
