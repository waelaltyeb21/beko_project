import AxiosConfig from "@/config/AxiosConfig";


export const GetData = async (url: string) => {
  if (!url) {
    throw new Error("URL is required");
  }

  const { data, status } = await AxiosConfig.get(url);
    if (status !== 200) {
        throw new Error(`HTTP error! status: ${status}`);
    }

  return data;
};
