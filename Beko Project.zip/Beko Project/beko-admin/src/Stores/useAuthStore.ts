import AxiosConfig from "@/config/AxiosConfig";
import { RequestController } from "@/lib/RequestController";
import { create } from "zustand";

// Define your user type based on what your API returns
interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  avatar: string;
}

// Define the state shape
interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAppInitialized: boolean;
  login: (email: string, password: string) => Promise<any>;
  logout: () => Promise<void>;
  resetPassword: (email: string, currentPassword: string, newPassword: string, confirmPassword: string) => Promise<any>;
  updateProfile: (name: string) => Promise<any>;
  refresh: () => Promise<{ user: User; token: string } | null>;
  getToken: () => string | null;
  bootstrap: () => Promise<boolean>;
}

const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  token: null,
  isLoading: true,
  isAppInitialized: false,

  // Login
  login: async (email, password) => {
    try {
      const response = await AxiosConfig.post("/auth/login", { email, password });
      if (response?.status === 200) {
        set({ token: response.data.token, user:response?.data?.supervisor, isLoading: false });
        return response?.data?.supervisor;
      }
      return null;
    } catch (error: any) {
      console.error(error);
      throw new Error(error?.response?.data?.message || "Failed to login");
    }
  },

  // Logout
  logout: async () => {
    try {
      const response = await AxiosConfig.get("/auth/logout");
      if (response?.status === 200) {
        set({
          token: null,
          user: null,
          isLoading: false,
          isAppInitialized: true,
        });
      }
    } catch (error: any) {
      throw new Error(error?.response?.data?.message || "Failed to logout");
    }
  },

  // Refresh Token
  refresh: async () => {
    try {
      const response = await AxiosConfig.get("/auth/refresh_token");
      if (response?.status === 200) {
        const user = response?.data?.supervisor as User;
        const token = response?.data?.token as string;
        set({ user, token });
        return { user, token };
      }
      return null;
    } catch {
      return null;
    }
  },
  
  // Reset Password
  resetPassword: async (email, currentPassword, newPassword, confirmPassword) => {
    try {
      
      const response = await AxiosConfig.post("/auth/reset_password", {email, currentPassword, newPassword, confirmPassword});

      if (response?.status === 200) {
        const user = response?.data?.supervisor as User;
        const token = response?.data?.token as string;
        set({ user, token });
        return { user, token };
      }

      return null;
    } catch (error: any) {
      console.error(error);
      throw new Error(error?.response?.data?.message || "Failed to reset password");
    }
  },

  // Update Profile
  updateProfile: async (name) => {
    try {
      const response = await RequestController(
        `/supervisors/update-supervisor/${get().user?.id}`,
        "PUT",
        {
          name:name,
        }
      );

      if (response?.status === 200) {
        const user = response?.data?.supervisor as User;
        const token = response?.data?.token as string;
        set({ user, token });
        return { user, token };
      }

    } catch (error) {
      throw new Error(`Error: ${error?.message}`);
    }
  },

  getToken: () => get().token,

  // Bootstrap
  bootstrap: async () => {
    try {
      const data = await get().refresh();
      if (!data?.user || !data?.token) {
        set({
          token: null,
          user: null,
          isLoading: false,
          isAppInitialized: true,
        });
        return false;
      }

      const { user, token } = data;
      set({ user, token, isLoading: false, isAppInitialized: true });
      return true;
    } catch (error: any) {
      set({
        token: null,
        user: null,
        isLoading: false,
        isAppInitialized: true,
      });
      return false;
    }
  },
}));

export default useAuthStore;
