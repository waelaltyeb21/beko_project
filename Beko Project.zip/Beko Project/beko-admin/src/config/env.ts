export const ENV = {
  SERVER_URL: import.meta.env.VITE_SERVER_URL,
  SERVER_UPLOADS: import.meta.env.VITE_SERVER_URL_UPLOADS,
  MODE: import.meta.env.MODE,
} as const;
