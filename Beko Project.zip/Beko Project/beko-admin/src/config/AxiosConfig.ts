import axios, { AxiosInstance } from "axios";
import { ENV } from "./env";
import useAuthStore from "@/Stores/useAuthStore";

const AxiosConfig: AxiosInstance = axios.create({
  baseURL: ENV.SERVER_URL,
  withCredentials: true,
  timeout: 10000,
});

// ✅ REQUEST INTERCEPTOR
AxiosConfig.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().getToken();
    if (token) {
      // config.headers = config.headers || {};
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// // ✅ RESPONSE INTERCEPTOR
// AxiosConfig.interceptors.response.use(
//   (response: AxiosResponse) => response,
//   async (error: AxiosError) => {
//     const originalRequest = error.config as CustomAxiosRequestConfig;

//     // No config, just reject
//     if (!originalRequest) return Promise.reject(error);

//     // Handle 401 + prevent infinite retry loops
//     if (error.response?.status === 401 && !originalRequest._retry) {
//       originalRequest._retry = true;

//       try {
//         const { token } = await useAuthStore.getState().refresh();
//         if (token) {
//           originalRequest.headers = originalRequest.headers || {};
//           originalRequest.headers.Authorization = `Bearer ${token}`;
//           return AxiosConfig(originalRequest);
//         }
//       } catch (refreshError) {
//         return Promise.reject(refreshError);
//       }
//     }

//     return Promise.reject(error);
//   }
// );

export default AxiosConfig;
