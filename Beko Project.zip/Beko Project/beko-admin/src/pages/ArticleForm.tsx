import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowRight } from "lucide-react";
import TipTapEditor from "@/components/editor/TipTapEditor";
import { GetData } from "@/lib/GetData";
import { RequestController } from "@/lib/RequestController";

interface ArticleFormData {
  title: {
    ar: string;
    en: string;
  };
  content: string;
  videoUrl?: string;
  imageUrl?: string;
  isPublished: boolean;
  publishedAt?: string;
}

const ArticleForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isEdit = !!id;
  const [content, setContent] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setValue,
    watch,
  } = useForm<ArticleFormData>({
    defaultValues: {
      title: {
        ar: "",
        en: "",
      },
      content: "",
      videoUrl: "",
      imageUrl: "",
      isPublished: true,
    },
  });

  const { data: article } = useQuery({
    queryKey: ["article", id],
    queryFn: () => GetData(`/blogs/${id}`),
    enabled: isEdit,
  });

  useEffect(() => {
    if (article) {
      setValue("title", article?.blog?.title);
      setValue("content", article?.blog?.content);
      setContent(article?.blog?.content);
      setValue("videoUrl", article?.blog?.videoUrl || "");
      setValue("imageUrl", article?.blog?.imageUrl || "");
      setValue("isPublished", article?.blog?.isPublished);
      setValue("publishedAt", article?.blog?.publishedAt || "");
    }
  }, [article, setValue]);

  const onSubmit = async (data: ArticleFormData) => {
    if (!content.trim() || content === "<p></p>") {
      toast.error("محتوى المقال مطلوب");
      return;
    }
    if (
      data.videoUrl &&
      !data.videoUrl.includes("youtube.com") &&
      !data.videoUrl.includes("youtu.be")
    ) {
      toast.error("رابط يوتيوب غير صحيح");
      return;
    }
    try {
      const url = isEdit ? `/blogs/update-blog/${id}` : "/blogs/add-blog";
      const method = isEdit ? "PUT" : "POST";
      const response = await RequestController(url, method, {
        title: data.title,
        content,
        videoUrl: data.videoUrl,
        imageUrl: data.imageUrl,
        isPublished: data.isPublished,
      });

      if (response?.status === 200 || response?.status === 201) {
        queryClient.invalidateQueries({ queryKey: ["articles"] });
        toast.success(
          isEdit ? "تم تحديث المقال بنجاح" : "تم إضافة المقال بنجاح"
        );
        navigate("/articles");
      }
    } catch (error) {
      throw new Error(`Error: ${error?.message}`);
    }
  };

  const isPublished = watch("isPublished");

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate("/articles")}>
          <ArrowRight className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">
            {isEdit ? "تعديل المقال" : "إضافة مقال جديد"}
          </h1>
          <p className="text-muted-foreground mt-1">
            {isEdit ? "قم بتحديث محتوى المقال" : "أضف مقال جديد إلى الموقع"}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>محتوى المقال</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">عنوان المقال بالعربي *</Label>
                <Input
                  id="title"
                  {...register("title.ar", { required: "عنوان المقال مطلوب" })}
                  placeholder="أدخل عنوان المقال"
                  className="text-right"
                />
                {errors.title?.ar && (
                  <p className="text-sm text-destructive">
                    {errors.title?.ar?.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="title">عنوان المقال بالانجليزي*</Label>
                <Input
                  id="title"
                  {...register("title.en", { required: "عنوان المقال مطلوب" })}
                  placeholder="أدخل عنوان المقال"
                  className="text-right"
                />
                {errors.title?.en && (
                  <p className="text-sm text-destructive">
                    {errors.title?.en?.message}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label>محتوى المقال *</Label>
              <TipTapEditor content={content} onChange={setContent} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="videoUrl">رابط فيديو يوتيوب*</Label>
              <Input
                id="videoUrl"
                {...register("videoUrl", { required: true })}
                placeholder="https://youtube.com/watch?v=..."
                className="text-right"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "جاري الحفظ..." : "نشر"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/articles")}
              >
                إلغاء
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ArticleForm;
