import { useEffect } from "react";
import { Controller, useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowRight } from "lucide-react";
import { RequestController } from "@/lib/RequestController";
import { GetData } from "@/lib/GetData";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface BranchFormData {
  name: {
    ar: string;
    en: string;
  };
  state: string;
  city: {
    ar: string;
    en: string;
  };
  address: {
    ar: string;
    en: string;
  };
  mapsUrl: string;
  status: string;
}

const BranchForm = () => {
  const { id } = useParams();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const isEdit = !!id;

  const {
    register,
    control,
    handleSubmit,
    formState: { errors, isLoading },
    setValue,
    watch,
  } = useForm<BranchFormData>({
    defaultValues: {
      name: { ar: "", en: "" },
      state: "",
      city: { ar: "", en: "" },
      address: { ar: "", en: "" },
      mapsUrl: "",
      status: "",
    },
  });

  const { data: branch } = useQuery({
    queryKey: ["branch", id],
    queryFn: () => GetData(`/branches/${id}`),
    enabled: isEdit,
  });

  useEffect(() => {
    if (branch) {
      setValue("name", branch.name);
      setValue("state", branch.state);
      setValue("city", branch.city);
      setValue("address", branch.address);
      setValue("mapsUrl", branch.mapsUrl);
      setValue("status", branch.status);
    }
  }, [branch, setValue]);

  const onSubmit = async (data: BranchFormData) => {
    try {
      const method = branch ? "PUT" : "POST";
      const url = branch
        ? `/branches/update-branch/${id}`
        : `/branches/add-branch`;

      const response = await RequestController(url, method, data);

      if (response.status === 201 || response.status === 200) {
        toast.success(response.data.message);
        queryClient.invalidateQueries({ queryKey: ["branch"] });
        navigate("/branches");
      }
    } catch (error) {}
  };

  const sudanStates = [
    { ar: "الخرطوم", en: "Khartoum" },
    { ar: "البحر الاحمر", en: "Red Sea" },
    { ar: "الجزيرة", en: "Al Jazirah" },
    { ar: "القضارف", en: "Gedaref" },
    { ar: "كسلا", en: "Kassala" },
    { ar: "نهر النيل", en: "River Nile" },
    { ar: "الشمالية", en: "Northern" },
    { ar: "سنار", en: "Sennar" },
    { ar: "النيل الأزرق", en: "Blue Nile" },
    { ar: "النيل الأبيض", en: "White Nile" },
    { ar: "شمال كردفان", en: "North Kordofan" },
    { ar: "جنوب كردفان", en: "South Kordofan" },
    { ar: "شمال دارفور", en: "North Darfur" },
    { ar: "جنوب دارفور", en: "South Darfur" },
    { ar: "غرب دارفور", en: "West Darfur" },
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate("/branches")}>
          <ArrowRight className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">
            {isEdit ? "تعديل الفرع" : "إضافة فرع جديد"}
          </h1>
          <p className="text-muted-foreground mt-1">
            {isEdit ? "قم بتحديث بيانات الفرع" : "أضف فرع جديد إلى القائمة"}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>بيانات الفرع</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid sm:grid-cols-2 grid-cols-1 gap-2">
              <div className="space-y-2">
                <Label htmlFor="name">اسم الفرع (بالعربي) *</Label>
                <Input
                  id="name"
                  {...register("name.ar", { required: "اسم الفرع مطلوب" })}
                  placeholder="أدخل اسم الفرع"
                  className="text-right"
                />
                {errors?.name?.ar && (
                  <p className="text-sm text-destructive">
                    {errors?.name?.ar?.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">اسم الفرع (بالانجليزي) *</Label>
                <Input
                  id="name"
                  {...register("name.en", { required: "اسم الفرع مطلوب" })}
                  placeholder="أدخل اسم الفرع"
                  className="text-right"
                />
                {errors?.name?.en && (
                  <p className="text-sm text-destructive">
                    {errors?.name?.en?.message}
                  </p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="state">الولاية *</Label>
                <Controller
                  control={control}
                  name="state"
                  render={({ field }) => (
                    <Select
                      dir="rtl"
                      value={field.value}
                      onValueChange={field.onChange}
                    >
                      <SelectTrigger className="text-right">
                        <SelectValue placeholder="اختر ولاية الفرع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          <SelectLabel>الولايات</SelectLabel>
                          {sudanStates.map((state) => (
                            <SelectItem key={state.ar} value={state.ar}>
                              {state.ar}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  )}
                />
                {errors.state && (
                  <p className="text-sm text-destructive">
                    {errors.state.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">المدينة بالعربي *</Label>
                <Input
                  id="city"
                  {...register("city.ar", { required: "المدينة مطلوبة" })}
                  placeholder="أدخل المدينة"
                  className="text-right"
                />
                {errors?.city?.ar && (
                  <p className="text-sm text-destructive">
                    {errors?.city?.ar?.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="city.en">المدينة بالانجليزي *</Label>
                <Input
                  id="city"
                  {...register("city.en", { required: "المدينة مطلوبة" })}
                  placeholder="أدخل المدينة"
                  className="text-right"
                />
                {errors?.city?.en && (
                  <p className="text-sm text-destructive">
                    {errors?.city?.en?.message}
                  </p>
                )}
              </div>
            </div>

            <div className="grid sm:grid-cols-2 grid-cols-1 gap-2">
              <div className="space-y-2">
                <Label htmlFor="address">الشارع (بالعربي) *</Label>
                <Input
                  id="address"
                  {...register("address.ar", { required: "الشارع مطلوب" })}
                  placeholder="أدخل الشارع"
                  className="text-right"
                />
                {errors?.address?.ar && (
                  <p className="text-sm text-destructive">
                    {errors?.address?.ar?.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">الشارع (بالانجليزي) *</Label>
                <Input
                  id="address"
                  {...register("address.en", { required: "الشارع مطلوب" })}
                  placeholder="أدخل الشارع"
                  className="text-right"
                />
                {errors?.address?.en && (
                  <p className="text-sm text-destructive">
                    {errors?.address?.en?.message}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="mapsUrl">رابط خرائط جوجل *</Label>
              <Input
                id="mapsUrl"
                {...register("mapsUrl", {
                  required: "رابط خرائط جوجل مطلوب",
                  pattern: {
                    value: /^https?:\/\/.+/,
                    message: "يرجى إدخال رابط صحيح",
                  },
                })}
                placeholder="https://maps.google.com/?q=..."
                className="text-right"
                dir="ltr"
              />
              {errors.mapsUrl && (
                <p className="text-sm text-destructive">
                  {errors.mapsUrl.message}
                </p>
              )}
            </div>

            <div className="flex flex-col gap-4 p-4 bg-accent/30 rounded-lg">
              <Label htmlFor="isActive">حالة التوافر</Label>

              <Controller
                control={control}
                name="status"
                render={({ field }) => (
                  <Select
                    dir="rtl"
                    value={field.value}
                    onValueChange={field.onChange}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر حالة الفرع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectLabel>حالة الفرع</SelectLabel>
                        <SelectItem value="soon">قريبا</SelectItem>
                        <SelectItem value="open">مفتوح</SelectItem>
                        <SelectItem value="closed">مغلق</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "جاري الحفظ..." : "حفظ"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/branches")}
              >
                إلغاء
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default BranchForm;
