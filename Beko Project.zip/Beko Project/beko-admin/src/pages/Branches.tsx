import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Plus, Search, Pencil, Trash2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import useFetch from "@/hooks/useFetch";
import { RequestController } from "@/lib/RequestController";

const Branches = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const navigate = useNavigate();

  const { data: branches = [], isLoading, refetch } = useFetch("/branches");

  const HandleDelete = async () => {
    try {
      const response = await RequestController(
        "/branches/delete-branch/" + deleteId,
        "DELETE"
      );

      if (response.status === 200) {
        toast.success(response.data.message);
        refetch();
        // queryClient.refetchQueries(["branches"]);
      }
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف المنتج");
      throw new Error(`Error: ${error?.response}`);
    }
  };

  const StatusVariants = {
    soon: "bg-blue-100 text-blue-700",
    open: "bg-green-100 text-green-700",
    closed: "bg-red-100 text-red-700",
  };

  const StatusTranslate = {
    soon: "قريبا",
    open: "مفتوح",
    closed: "مغلق",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">الفروع</h1>
          <p className="text-muted-foreground mt-1">إدارة فروع بيكو</p>
        </div>
        <Button onClick={() => navigate("/branches/new")}>
          <Plus className="ml-2 h-4 w-4" />
          إضافة فرع جديد
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث عن فرع..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">جاري التحميل...</div>
          ) : branches.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد فروع
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full *:whitespace-nowrap">
                <thead>
                  <tr className="border-b">
                    <th className="text-right py-3 px-4 font-semibold">
                      اسم الفرع
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      الولاية
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      المدينة
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      خرائط جوجل
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      الحالة
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      الإجراءات
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {branches.map((branch: any) => (
                    <tr
                      key={branch?.id}
                      className="last:border-0 border-b hover:bg-accent/50 transition-colors"
                    >
                      <td className="py-3 px-4">{branch?.name?.ar}</td>
                      <td className="py-3 px-4">{branch?.state}</td>
                      <td className="py-3 px-4">{branch?.city?.ar}</td>
                      <td className="py-3 px-4">
                        <Link
                          to={branch?.mapsUrl || ""}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:underline"
                        >
                          عرض الموقع
                        </Link>
                      </td>
                      <td className="py-3 px-4">
                        <div
                          className={`${
                            StatusVariants[branch?.status || "soon"]
                          } rounded-md text-center`}
                        >
                          {StatusTranslate[branch?.status]}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              navigate(`/branches/edit/${branch?.id}`)
                            }
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => setDeleteId(branch?.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>هل أنت متأكد؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف هذا الفرع نهائياً ولا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={HandleDelete}
              className="bg-destructive hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Branches;
