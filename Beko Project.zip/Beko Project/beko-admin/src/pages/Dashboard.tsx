import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShoppingBag, FileText, MapPin, Settings } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { GetData } from "@/lib/GetData";
import { NumberFormat } from "@/lib/NumberFormat";

const Dashboard = () => {
  const { data: statistics = [] } = useQuery({
    queryKey: ["statistics"],
    queryFn: () => GetData("/statistics"),
  });

  const StatusVariants = {
    soon: "bg-blue-100 text-blue-700",
    open: "bg-green-100 text-green-700",
    closed: "bg-red-100 text-red-700",
  };

  const StatusTranslate = {
    soon: "قريبا",
    open: "مفتوح",
    closed: "مغلق",
  };

  const statsCards = [
    {
      id: 1,
      title: "عدد المنتجات",
      value: statistics?.totals?.products,
      icon: ShoppingBag,
      color: "text-chart-1",
      bgColor: "bg-chart-1/10",
    },
    {
      id: 2,
      title: "المقالات المنشورة",
      value: statistics?.totals?.blogs,
      icon: FileText,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
    },
    {
      id: 3,
      title: "الفروع النشطة",
      value: statistics?.totals?.branches,
      icon: MapPin,
      color: "text-chart-3",
      bgColor: "bg-chart-3/10",
    },
    {
      id: 4,
      title: "آخر تحديث",
      value: new Date(Date.now()).toLocaleDateString("ar-SD"),
      icon: Settings,
      color: "text-chart-4",
      bgColor: "bg-chart-4/10",
    },
  ];

  return (
    <div className="space-y-4 md:space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground">
          لوحة المعلومات
        </h1>
        <p className="text-sm md:text-base text-muted-foreground mt-1">
          نظرة عامة على نشاط النظام
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statsCards.map((stat) => (
          <Card key={stat.id}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid sm:grid-cols-2 grid-cols-1 gap-4 md:gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base md:text-lg">نشاط النظام</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart
                data={[
                  {
                    id: 1,
                    name: "المنتجات",
                    value: statistics?.totals?.products,
                  },
                  { id: 2, name: "المقالات", value: statistics?.totals?.blogs },
                  {
                    id: 3,
                    name: "الفروع",
                    value: statistics?.totals?.branches,
                  },
                ]}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="hsl(var(--chart-1))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Latest Items */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base md:text-lg">
              أحدث المنتجات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 md:space-y-3">
              {statistics?.latest?.products.map((product: any) => (
                <div
                  key={product.id}
                  className="flex items-center justify-between p-2 md:p-3 bg-accent/30 rounded-lg"
                >
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-sm md:text-base truncate">
                      {product.name["ar"]}
                    </p>
                    <p className="text-xs md:text-sm text-muted-foreground">
                      {NumberFormat(product.price)}
                    </p>
                  </div>
                  <span
                    className={`px-2 py-1 text-xs rounded-full ${
                      product.is_available
                        ? "bg-success/20 text-success"
                        : "bg-destructive/20 text-destructive"
                    }`}
                  >
                    {product.is_available ? "متوفر" : "غير متوفر"}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base md:text-lg">أحدث الفروع</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 md:space-y-3">
              {statistics?.latest?.branches.map((branch: any) => (
                <div
                  key={branch?.id}
                  className="flex items-center justify-between p-2 md:p-3 bg-accent/30 rounded-lg"
                >
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-sm md:text-base truncate">
                      {branch?.name["ar"]}
                    </p>
                    <p className="text-xs md:text-sm text-muted-foreground">
                      {branch?.city["ar"]} - {branch?.address["ar"]}
                    </p>
                  </div>
                  <span
                    className={`px-2 py-1 text-xs rounded-full ${
                      StatusVariants[branch?.status]
                    }`}
                  >
                    {StatusTranslate[branch?.status]}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base md:text-lg">
              أحدث المقالات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 md:space-y-3">
              {statistics?.latest?.blogs?.length == 0 ? (
                <div className="size-full flex items-center justify-center mt-16">
                  لا توجد مقالات
                </div>
              ) : (
                statistics?.latest?.blogs.map((blog: any) => (
                  <div
                    key={blog?.id}
                    className="flex items-center justify-between p-2 md:p-3 bg-accent/30 rounded-lg"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-sm md:text-base truncate">
                        {blog?.title["ar"]}
                      </p>
                      <p className="text-xs md:text-sm text-muted-foreground">
                        {blog?.createdAt
                          ? new Date(
                              blog?.createdAt || new Date()
                            ).toLocaleDateString("ar-SD", {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })
                          : "غير منشور"}
                      </p>
                    </div>
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        blog?.status
                          ? "bg-success/20 text-success"
                          : "bg-warning/20 text-warning"
                      }`}
                    >
                      منشور
                      {/* {blog?.isPublished ? "منشور" : "مسودة"} */}
                    </span>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
