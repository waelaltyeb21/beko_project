import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import useAuthStore from "@/Stores/useAuthStore";

interface ProfileFormData {
  name: string;
  email: string;
  avatarUrl?: string;
}

interface PasswordFormData {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

const Profile = () => {
  const { user, updateProfile, resetPassword } = useAuthStore();

  const {
    watch,
    register: registerProfile,
    handleSubmit: handleSubmitProfile,
    formState: { errors: profileErrors, isSubmitting: loading },
    setValue,
  } = useForm<ProfileFormData>();

  const {
    register: registerPassword,
    handleSubmit: handleSubmitPassword,
    formState: { errors: passwordErrors, isSubmitting },
    setValue: setPasswordValue,
  } = useForm<PasswordFormData>();

  useEffect(() => {
    if (user) {
      setValue("name", user.name);
      setValue("email", user.email);
    }
  }, [user, setValue]);

  const onSubmitProfile = async (data: ProfileFormData) => {
    try {
      if (user?.name === data.name) {
        toast.error("لم يتم إجراء أي تغييرات على الملف الشخصي");
        return;
      }
      const { user: updatedUser } = await updateProfile(data.name);
      setValue("name", updatedUser.name || "");

      toast.success("تم تحديث الملف الشخصي بنجاح");
    } catch (error) {
      throw new Error(`Error: ${error?.message}`);
    }
  };

  const onSubmitPassword = async (data: PasswordFormData) => {
    if (data.newPassword !== data.confirmPassword) {
      toast.error("كلمة المرور الجديدة وتأكيد كلمة المرور غير متطابقتين");
      return;
    }
    if (data.newPassword.length < 8) {
      toast.error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
      return;
    }

    try {
      await resetPassword(
        user?.email,
        data.currentPassword,
        data.newPassword,
        data.confirmPassword
      );

      setPasswordValue("currentPassword", "");
      setPasswordValue("newPassword", "");
      setPasswordValue("confirmPassword", "");

      toast.success("تم تغيير كلمة المرور بنجاح");
    } catch (error) {
      throw new Error(`Error: ${error?.message}`);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">الحساب الشخصي</h1>
        <p className="text-muted-foreground mt-1">إدارة معلومات حسابك</p>
      </div>

      {/* Profile Information */}
      <Card>
        <CardHeader>
          <CardTitle>المعلومات الشخصية</CardTitle>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={handleSubmitProfile(onSubmitProfile)}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="name">الاسم *</Label>
              <Input
                id="name"
                {...registerProfile("name", { required: "الاسم مطلوب" })}
                placeholder="أدخل اسمك"
                className="text-right"
              />
              {profileErrors.name && (
                <p className="text-sm text-destructive">
                  {profileErrors.name.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني *</Label>
              <Input
                id="email"
                type="email"
                disabled
                {...registerProfile("email", {
                  required: "البريد الإلكتروني مطلوب",
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: "البريد الإلكتروني غير صحيح",
                  },
                })}
                placeholder="email@example.com"
                className="text-right"
              />
              {profileErrors.email && (
                <p className="text-sm text-destructive">
                  {profileErrors.email.message}
                </p>
              )}
            </div>

            {/* <div className="space-y-2">
              <Label htmlFor="avatarUrl">رابط الصورة الشخصية</Label>
              <Input
                id="avatarUrl"
                {...registerProfile("avatarUrl")}
                placeholder="https://example.com/avatar.jpg"
                className="text-right"
              />
            </div> */}

            <Button
              type="submit"
              disabled={loading || user?.name === watch("name")}
            >
              {loading ? "جاري الحفظ..." : "حفظ التغييرات"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Change Password */}
      <Card>
        <CardHeader>
          <CardTitle>تغيير كلمة المرور</CardTitle>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={handleSubmitPassword(onSubmitPassword)}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="currentPassword">كلمة المرور الحالية *</Label>
              <Input
                id="currentPassword"
                type="password"
                {...registerPassword("currentPassword", {
                  required: "كلمة المرور الحالية مطلوبة",
                })}
                placeholder="••••••••"
                className="text-right"
              />
              {passwordErrors.currentPassword && (
                <p className="text-sm text-destructive">
                  {passwordErrors.currentPassword.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="newPassword">كلمة المرور الجديدة *</Label>
              <Input
                id="newPassword"
                type="password"
                {...registerPassword("newPassword", {
                  required: "كلمة المرور الجديدة مطلوبة",
                  minLength: {
                    value: 8,
                    message: "كلمة المرور يجب أن تكون 8 أحرف على الأقل",
                  },
                })}
                placeholder="••••••••"
                className="text-right"
              />
              {passwordErrors.newPassword && (
                <p className="text-sm text-destructive">
                  {passwordErrors.newPassword.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">تأكيد كلمة المرور *</Label>
              <Input
                id="confirmPassword"
                type="password"
                {...registerPassword("confirmPassword", {
                  required: "تأكيد كلمة المرور مطلوب",
                })}
                placeholder="••••••••"
                className="text-right"
              />
              {passwordErrors.confirmPassword && (
                <p className="text-sm text-destructive">
                  {passwordErrors.confirmPassword.message}
                </p>
              )}
            </div>

            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "جاري التغيير..." : "تغيير كلمة المرور"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Profile;
