import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { ArrowRight } from "lucide-react";
import { GetData } from "@/lib/GetData";
import { Textarea } from "@/components/ui/textarea";
import { RequestController } from "@/lib/RequestController";

interface ProductFormData {
  name: {
    ar: string;
    en: string;
  };
  image: FileList;
  price: number;
  description: {
    ar: string;
    en: string;
  };
  is_available: boolean;
}

const ProductForm = () => {
  const { id } = useParams();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const isEdit = !!id;
  const [imagePreview, setImagePreview] = useState<FileList | string | null>(
    null
  );

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting: loading },
    setValue,
    watch,
  } = useForm<ProductFormData>({
    defaultValues: {
      name: {
        ar: "",
        en: "",
      },
      price: 0,
      description: {
        ar: "",
        en: "",
      },
      is_available: true,
    },
  });

  const { data: product } = useQuery({
    queryKey: ["product", id],
    queryFn: () => GetData(`/products/${id}`),
    enabled: isEdit,
    staleTime: 0,
    gcTime: 0,
  });

  useEffect(() => {
    if (product) {
      setValue("name", product.name);
      setValue("image", product.imageUrl);
      setValue("description", product.description);
      setValue("price", product.price);
      setValue("is_available", product.is_available);
      setImagePreview(
        `${import.meta.env.VITE_SERVER_URL_UPLOADS}/products/${
          product.imageUrl
        }`
      );
    }
  }, [product, setValue]);

  const onSubmit = async (data: ProductFormData) => {
    if (data.price <= 0) {
      toast.error("السعر يجب أن يكون أكبر من صفر");
      return;
    }

    try {
      const method = isEdit ? "PUT" : "POST";
      const url = isEdit
        ? `/products/update-product/${id}`
        : `/products/add-product`;

      const formData = new FormData();
      formData.append("name", JSON.stringify(data.name));
      formData.append("price", data.price.toString());
      formData.append("description", JSON.stringify(data.description));
      formData.append("is_available", data.is_available.toString());

      const file = data?.image?.[0];
      if (file) {
        formData.append("product", file);
      }

      const response = await RequestController(url, method, formData, {
        "Content-Type": "multipart/form-data",
      });

      if (response && (response.status === 200 || response.status === 201)) {
        toast.success(response.data.message);
        await queryClient.invalidateQueries({ queryKey: ["products"] });
        await queryClient.invalidateQueries({ queryKey: ["product", id] });

        navigate("/products");
      }
    } catch (error) {
      toast.error("حدث خطأ أثناء حفظ المنتج");
    }
  };

  const isAvailable = watch("is_available");

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate("/products")}>
          <ArrowRight className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">
            {isEdit ? "تعديل المنتج" : "إضافة منتج جديد"}
          </h1>
          <p className="text-muted-foreground mt-1">
            {isEdit ? "قم بتحديث بيانات المنتج" : "أضف منتج جديد إلى القائمة"}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>بيانات المنتج</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name_ar">اسم المنتج ( بالعربي) *</Label>
                <Input
                  id="name_ar"
                  {...register("name.ar", { required: "اسم المنتج مطلوب" })}
                  placeholder="أدخل اسم المنتج"
                  className="text-right"
                />
                {errors.name && (
                  <p className="text-sm text-destructive">
                    {errors.name.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="name_en">اسم المنتج ( بالانجليزي) *</Label>
                <Input
                  id="name_en"
                  {...register("name.en", { required: "اسم المنتج مطلوب" })}
                  placeholder="أدخل اسم المنتج"
                  className="text-right"
                />
                {errors.name && (
                  <p className="text-sm text-destructive">
                    {errors.name.message}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description_ar">وصف المنتج ( بالعربي) *</Label>
              <Textarea
                id="description_ar"
                {...register("description.ar", {
                  required: "اسم المنتج مطلوب",
                })}
                placeholder="أدخل اسم المنتج"
                className="text-right"
              />
              {errors.description && (
                <p className="text-sm text-destructive">
                  {errors.description.message}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="description_en">وصف المنتج ( بالانجليزي) *</Label>
              <Textarea
                id="description_en"
                {...register("description.en", {
                  required: "اسم المنتج مطلوب",
                })}
                placeholder="أدخل اسم المنتج"
                className="text-right"
              />
              {errors.description && (
                <p className="text-sm text-destructive">
                  {errors.description.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">السعر (جنيه) *</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                {...register("price", {
                  required: "السعر مطلوب",
                  valueAsNumber: true,
                  min: {
                    value: 0.01,
                    message: "السعر يجب أن يكون أكبر من صفر",
                  },
                })}
                placeholder="0.00"
                className="text-right"
              />
              {errors.price && (
                <p className="text-sm text-destructive">
                  {errors.price.message}
                </p>
              )}
            </div>

            {imagePreview && (
              <div className="col-span-2 space-x-2">
                <Label>معاينة صورة المنتج:</Label>
                <img
                  src={
                    typeof imagePreview === "string"
                      ? imagePreview
                      : URL.createObjectURL(imagePreview[0])
                  }
                  alt="معاينة صورة المنتج"
                  className="mt-2 max-h-48 rounded-md border"
                />
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="image">صورة المنتج *</Label>
              <Input
                id="image"
                type="file"
                accept="image/*"
                // {...register("image", {
                //   required: isEdit ? false : "صورة المنتج مطلوبة",
                // })}
                onChange={(e) => {
                  const file = URL.createObjectURL(e.target.files![0]);
                  setValue("image", e.target.files as FileList);
                  setImagePreview(file);
                }}
                placeholder="أدخل رابط صورة المنتج"
                className="text-right"
              />
              {errors.image && (
                <p className="text-sm text-destructive">
                  {errors.image.message}
                </p>
              )}
            </div>

            <div className="flex items-center justify-between p-4 bg-accent/30 rounded-lg">
              <div className="space-y-0.5">
                <Label htmlFor="is_available">حالة التوفر</Label>
                <p className="text-sm text-muted-foreground">
                  هل المنتج متوفر حالياً؟
                </p>
              </div>
              <Switch
                id="is_available"
                checked={isAvailable}
                onCheckedChange={(checked) => setValue("is_available", checked)}
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="submit" disabled={loading}>
                {loading ? "جاري الحفظ..." : "حفظ"}
              </Button>
              <Button
                type="button"
                variant="outline"
                disabled={loading}
                onClick={() => navigate("/products")}
              >
                إلغاء
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProductForm;
