import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Pencil, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { GetData } from "@/lib/GetData";
import { RequestController } from "@/lib/RequestController";
import { NumberFormat } from "@/lib/NumberFormat";

const Products = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: () => GetData("/products"),
    staleTime: 0,
    gcTime: 0,
  });

  const HandleDelete = async (id: number) => {
    try {
      const response = await RequestController(
        "/products/delete-product/" + id,
        "DELETE"
      );

      if (response.status === 200) {
        toast.success(response.data.message);
        queryClient.refetchQueries({ queryKey: ["products"] });
      }
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف المنتج");
    }
  };

  if (isLoading) return <>جاري التحميل...</>;

  const filteredProducts = products.filter(
    (product: any) =>
      product.name?.ar?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.name?.en?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">المنتجات</h1>
          <p className="text-muted-foreground mt-1">إدارة منتجات بيكو</p>
        </div>
        <Button onClick={() => navigate("/products/new")}>
          <Plus className="ml-2 h-4 w-4" />
          إضافة منتج جديد
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث عن منتج..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">جاري التحميل...</div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد منتجات
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full *:whitespace-nowrap">
                <thead>
                  <tr className="border-b">
                    <th className="text-right py-3 px-4 font-semibold">
                      اسم المنتج
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      السعر
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      حالة التوفر
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      تاريخ الإنشاء
                    </th>
                    <th className="text-right py-3 px-4 font-semibold">
                      الإجراءات
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product: any) => (
                    <tr
                      key={product.id}
                      className="border-b hover:bg-accent/50 transition-colors"
                    >
                      <td className="py-3 px-4 whitespace-nowrap">
                        {product.name?.ar}
                      </td>
                      <td className="py-3 px-4">
                        {NumberFormat(product.price)}
                      </td>
                      <td className="py-3 px-4">
                        <Badge
                          variant={
                            product.is_available ? "default" : "secondary"
                          }
                        >
                          {product.is_available ? "متوفر" : "غير متوفر"}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {new Date(product.createdAt).toLocaleDateString(
                          "en-SD"
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              navigate(`/products/edit/${product.id}`)
                            }
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => setDeleteId(product.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>هل أنت متأكد؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف هذا المنتج نهائياً ولا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && HandleDelete(deleteId)}
              className="bg-destructive hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Products;
