import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import useAuthStore from "./Stores/useAuthStore.ts";
import { useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";

const BootStrap = ({ children }) => {
  const { bootstrap, isLoading, isAppInitialized } = useAuthStore();

  useEffect(() => {
    const initializeApp = async () => {
      await bootstrap();
    };

    initializeApp();
  }, [bootstrap]);

  if (isLoading || !isAppInitialized) {
    return (
      <div className="d-flex justify-content-center align-items-center min-h-dvh">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
        <div className="ms-3">جاري التحميل...</div>
      </div>
    );
  }
  return children;
};

createRoot(document.getElementById("root")!).render(
  <BootStrap>
    <Toaster />
    <Sonner />
    <App />
  </BootStrap>
);
