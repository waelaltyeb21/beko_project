export interface Product {
  id: string;
  name: string;
  price: number;
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Article {
  id: string;
  title: string;
  content: string;
  publishedAt?: string;
  youtubeUrl?: string;
  imageUrl?: string;
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Branch {
  id: string;
  name: string;
  state: string;
  city: string;
  mapsUrl: string;
  isActive: boolean;
}

export interface SiteSettings {
  id: string;
  logoUrl?: string;
  slogan: string;
  enableProducts: boolean;
  enableArticles: boolean;
  enableBranches: boolean;
  enableDealers: boolean;
  enableContact: boolean;
  facebookUrl?: string;
  instagramUrl?: string;
  twitterUrl?: string;
  youtubeUrl?: string;
  whatsappNumber?: string;
  phoneNumber?: string;
  email?: string;
  updatedAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  createdAt: string;
  updatedAt: string;
}
