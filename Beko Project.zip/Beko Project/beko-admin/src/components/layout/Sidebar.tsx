import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  ShoppingBag,
  FileText,
  MapPin,
  User,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import useAuthStore from "@/Stores/useAuthStore";

const menuItems = [
  { title: "لوحة المعلومات", href: "/", icon: LayoutDashboard },
  { title: "المنتجات", href: "/products", icon: ShoppingBag },
  { title: "المقالات", href: "/articles", icon: FileText },
  { title: "الفروع", href: "/branches", icon: MapPin },
  { title: "الحساب الشخصي", href: "/profile", icon: User },
];

interface SidebarProps {
  isMobile?: boolean;
  isOpen?: boolean;
  onClose?: () => void;
}

const Sidebar = ({
  isMobile = false,
  isOpen = false,
  onClose,
}: SidebarProps) => {
  const { logout } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast.success("تم تسجيل الخروج بنجاح");
    navigate("/login");
  };

  const handleNavClick = () => {
    if (isMobile && onClose) {
      onClose();
    }
  };

  const sidebarContent = (
    <aside className="w-64 bg-card h-full flex flex-col">
      <div className="p-6 border-b border-border">
        <h1 className="text-2xl font-bold text-primary">بيكو</h1>
        <p className="text-sm text-muted-foreground mt-1">لوحة التحكم</p>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => (
          <NavLink
            key={item.href}
            to={item.href}
            end={item.href === "/"}
            onClick={handleNavClick}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
                "hover:bg-accent hover:text-accent-foreground",
                isActive
                  ? "bg-primary text-primary-foreground font-medium"
                  : "text-foreground"
              )
            }
          >
            <item.icon className="h-5 w-5" />
            <span>{item.title}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-border">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 rounded-lg w-full text-right hover:bg-destructive/10 hover:text-destructive transition-colors"
        >
          <LogOut className="h-5 w-5" />
          <span>تسجيل الخروج</span>
        </button>
      </div>
    </aside>
  );

  if (isMobile) {
    return (
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent side="right" className="p-0 w-64">
          {sidebarContent}
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <aside className="w-64 bg-card border-l border-border h-screen flex flex-col">
      {sidebarContent}
    </aside>
  );
};

export default Sidebar;
