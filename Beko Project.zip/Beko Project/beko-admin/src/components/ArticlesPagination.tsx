import { useEffect, useState } from "react";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "./ui/pagination";

const ArticlesPagination = ({
  meta = { total: 1, totalPages: 1, perPage: 1, currentPage: 1 },
  handleFilters,
}) => {
  const { totalPages, currentPage } = meta;
  const [page, setPage] = useState(currentPage);

  useEffect(() => {
    setPage(currentPage);
  }, [currentPage]);

  const HandlePaginate = (targetPage: number) => {
    if (targetPage < 1 || targetPage > totalPages || targetPage === currentPage)
      return;
    handleFilters("page", targetPage);
  };

  return (
    <div className="my-10 flex justify-center">
      <Pagination>
        <PaginationContent>
          <PaginationItem>
            <PaginationPrevious
              onClick={(e) => {
                e.preventDefault();
                HandlePaginate(page - 1);
              }}
              className={
                currentPage === 1 ? "pointer-events-none opacity-50" : ""
              }
            />
          </PaginationItem>

          {Array.from({ length: totalPages }, (_, i) => i + 1).map((num) => (
            <PaginationItem key={num}>
              <PaginationLink
                onClick={(e) => {
                  e.preventDefault();
                  HandlePaginate(num);
                }}
                isActive={currentPage === num}
              >
                {num}
              </PaginationLink>
            </PaginationItem>
          ))}

          <PaginationItem>
            <PaginationNext
              onClick={(e) => {
                e.preventDefault();
                HandlePaginate(page + 1);
              }}
              className={
                currentPage === totalPages
                  ? "pointer-events-none opacity-50"
                  : ""
              }
            />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
    </div>
  );
};

export default ArticlesPagination;
