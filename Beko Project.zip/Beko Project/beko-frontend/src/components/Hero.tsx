import { ReactNode } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { cn } from "@/lib/utils";

interface HeroProps {
  title: string;
  subtitle?: string;
  description?: string;
  children?: ReactNode;
  imageUrl?: string;
  className?: string;
}

export const Hero = ({
  title,
  subtitle,
  description,
  children,
  imageUrl,
  className,
}: HeroProps) => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 150]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  return (
    <section
      className={cn(
        "relative overflow-hidden min-h-[85vh] flex items-center",
        className
      )}
    >
      {/* Animated Background Image with Parallax */}
      {imageUrl && (
        <motion.div style={{ y }} className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-black/40 z-10" />
          {/* <div className="absolute inset-0 hero-pattern-modern opacity-30 z-20" /> */}
          <img
            src={imageUrl}
            alt="hero_products"
            className="w-full h-full object-cover scale-110"
            loading="eager"
          />
        </motion.div>
      )}

      {/* Gradient Overlay when no image */}
      {!imageUrl && (
        <div className="absolute inset-0 hero-gradient-modern hero-pattern-modern" />
      )}

      {/* Animated Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute -top-1/4 -right-1/4 w-1/2 h-1/2 bg-beko-blue-light rounded-full blur-3xl opacity-20"
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1,
          }}
          className="absolute -bottom-1/4 -left-1/4 w-1/2 h-1/2 bg-primary rounded-full blur-3xl opacity-20"
        />
      </div>

      {/* Content */}
      <motion.div
        style={{ opacity }}
        className="relative -top-24 z-30 container mx-auto px-4 py-24 md:py-32"
      >
        <div className="max-w-5xl mx-auto text-center">
          {subtitle && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="mb-6"
            >
              <span className="inline-block px-6 py-2.5 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-sm md:text-base font-semibold text-primary-foreground uppercase tracking-wider shadow-soft">
                {subtitle}
              </span>
            </motion.div>
          )}

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black text-primary-foreground mb-8 leading-[1.1] tracking-tight"
            style={{
              textShadow: "0 4px 20px rgba(0, 0, 0, 0.3)",
            }}
          >
            {title}
          </motion.h1>

          {description && (
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-xl md:text-2xl lg:text-3xl text-primary-foreground/95 mb-10 leading-relaxed max-w-4xl mx-auto font-medium"
              style={{
                textShadow: "0 2px 10px rgba(0, 0, 0, 0.2)",
              }}
            >
              {description}
            </motion.p>
          )}

          {children && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="flex flex-wrap items-center justify-center gap-4"
            >
              {children}
            </motion.div>
          )}
        </div>
      </motion.div>

      {/* Bottom Wave Transition */}
      <div className="absolute bottom-0 left-0 right-0 z-20">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-auto"
          preserveAspectRatio="none"
        >
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0V120Z"
            fill="hsl(var(--background))"
          />
        </svg>
      </div>
    </section>
  );
};
