import { useTranslation } from "react-i18next";

const BrandTagline = () => {
  const { t } = useTranslation("common");

  return (
    <section className="py-16 bg-secondary/50">
      <div className="container mx-auto px-4 text-center">
        <p className="text-2xl md:text-3xl font-semibold text-primary max-w-3xl mx-auto leading-relaxed">
          <q>{t("slogan")}</q>
        </p>
      </div>
    </section>
  );
};

export default BrandTagline;
