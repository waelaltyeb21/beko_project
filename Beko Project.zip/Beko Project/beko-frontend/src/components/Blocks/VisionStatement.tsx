import { TrendingUp } from "lucide-react";
import { useTranslation } from "react-i18next";

const VisionStatement = () => {
  const { t } = useTranslation();
  return (
    <section className="py-20 bg-gradient-to-tr from-primary to-primary/70 text-white">
      <div className="container mx-auto px-4 text-center">
        <TrendingUp className="h-16 w-16 mx-auto mb-6 opacity-90" />
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          {t("vision.title")}
        </h2>
        <p className="text-xl max-w-3xl mx-auto leading-relaxed">
          {t("vision.content")}
        </p>
      </div>
    </section>
  );
};

export default VisionStatement;
