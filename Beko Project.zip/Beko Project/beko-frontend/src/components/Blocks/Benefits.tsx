import {
  Award,
  CheckCircle2,
  Handshake,
  MapPin,
  TrendingUp,
  Users,
} from "lucide-react";
import { Card, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { useTranslation } from "react-i18next";

const Benefits = () => {
  const { t } = useTranslation("dealers");

  const benefits = [
    { icon: Award, key: "benefit1" },
    { icon: TrendingUp, key: "benefit2" },
    { icon: CheckCircle2, key: "benefit3" },
    { icon: Handshake, key: "benefit4" },
    { icon: MapPin, key: "benefit5" },
    { icon: Users, key: "benefit6" },
  ];

  return (
    <section>
      {/* Hero Section */}
      <section className="py-10 bg-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            {t("hero.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-12">
            {t("hero.subtitle")}
          </p>
        </div>
      </section>

      {/* Benefits Grid */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">
            {t("pitch.title")}
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="hover-lift">
                <CardHeader>
                  <benefit.icon className="h-12 w-12 text-primary mb-4" />
                  <CardTitle>{t(`pitch.${benefit.key}.title`)}</CardTitle>
                  <CardDescription>
                    {t(`pitch.${benefit.key}.description`)}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </section>
  );
};

export default Benefits;
