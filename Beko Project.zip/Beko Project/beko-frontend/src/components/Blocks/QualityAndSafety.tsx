import { CheckCircle2 } from "lucide-react";
import { useTranslation } from "react-i18next";

const QualityAndSafety = () => {
  const { t } = useTranslation("home");

  const items = t("qualitySection.items", { returnObjects: true }) as {
    key: string;
    title: string;
    description: string;
  }[];

  return (
    <section className="bg-background py-40">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-4xl">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold md:text-4xl">
              {t("qualitySection.title")}
            </h2>
            <p className="text-lg text-muted-foreground">
              {t("qualitySection.subtitle")}
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {items.map((item) => (
              <div
                key={item.key}
                className="flex gap-4 rounded-lg bg-muted/50 p-6"
              >
                <CheckCircle2 className="mt-1 h-6 w-6 flex-shrink-0 text-primary" />
                <div>
                  <h3 className="mb-1 text-lg font-semibold">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default QualityAndSafety;
