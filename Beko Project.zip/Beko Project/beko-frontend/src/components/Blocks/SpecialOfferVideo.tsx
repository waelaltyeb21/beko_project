import { Section } from "../Section";
import { motion } from "framer-motion";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Link } from "react-router-dom";
import { Play, Sparkles } from "lucide-react";
import { useTranslation } from "react-i18next";

const SpecialOfferVideo = () => {
  const { t } = useTranslation(["home", "common"]);

  return (
    <Section className="bg-gradient-to-br from-primary/10 via-primary/5 to-background relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary rounded-full blur-3xl" />
      </div>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="grid md:grid-cols-2 gap-12 items-center relative z-10"
      >
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="aspect-video bg-muted rounded-2xl overflow-hidden shadow-strong relative group"
        >
          <img
            src="/placeholder.svg"
            alt="Special Offer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/20 transition-colors">
            <div className="w-16 h-16 rounded-full bg-white/90 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Play className="h-8 w-8 text-primary ml-1" />
            </div>
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <Badge className="mb-4 text-base px-4 py-2">
            <Sparkles className="h-4 w-4 mr-2" />
            {t("home:offer.title")}
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            {t("home:offer.subtitle")}
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Don't miss our exclusive weekend promotions on premium quality meat
            products. Limited time only!
          </p>
          <Button size="lg" asChild>
            <Link to="/news">{t("common:cta.learnMore")}</Link>
          </Button>
        </motion.div>
      </motion.div>
    </Section>
  );
};

export default SpecialOfferVideo;
