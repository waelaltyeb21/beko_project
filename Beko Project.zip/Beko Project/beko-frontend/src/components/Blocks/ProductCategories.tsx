import { Card, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { useTranslation } from "react-i18next";
import useFetch from "@/hooks/useFetch";
import { useLanguage } from "@/hooks/useLanguage";
import Loading from "../Loading";

const ProductCategories = () => {
  const { t } = useTranslation(["products", "common"]);
  const { currentLanguage } = useLanguage();
  const { data: products, isLoading, error } = useFetch("/products");
  const UPLOADS = `${import.meta.env.VITE_SERVER_URL_UPLOADS}/products`;

  if (isLoading) return <Loading />;
  if (error) return null;
  if (!products || products.length === 0) return null;
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            {t("products:title")}
          </h2>
          <p className="text-lg text-black max-w-2xl mx-auto">
            {t("products:intro")}
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.slice(0, 7).map((product: any, index: number) => {
            const imageUrl =
              `${UPLOADS}/${product.imageUrl}` || "/placeholder.jpg";
            return (
              <Card
                key={index}
                className="bg-white/10 border-white/20 text-white hover-lift overflow-hidden"
              >
                <div className="relative aspect-video overflow-hidden bg-gradient-to-br from-muted to-muted/50">
                  <img
                    src={imageUrl}
                    alt={product?.name[currentLanguage]}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-black">
                    {product.name[currentLanguage]}
                  </CardTitle>
                </CardHeader>
              </Card>
            );
          })}
        </div>
        <div className="text-center mt-8">
          <Button asChild size="lg" variant="default">
            <Link to="/products">
              {t("common:viewAll")}
              <ArrowUpRight className="ms-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProductCategories;
