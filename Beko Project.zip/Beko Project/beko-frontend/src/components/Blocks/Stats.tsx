import { Section } from "../Section";
import { useTranslation } from "react-i18next";

const Stats = () => {
  const { t } = useTranslation("about");

  const stats = t("statsSection.items", {
    returnObjects: true,
  }) as { key: string; value: string; label: string }[];

  return (
    <Section className="bg-background py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {stats.map((stat) => (
            <div key={stat.key} className="text-center">
              <div className="mb-2 text-4xl font-bold text-primary md:text-5xl">
                {stat.value}
              </div>
              <div className="text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
};

export default Stats;
