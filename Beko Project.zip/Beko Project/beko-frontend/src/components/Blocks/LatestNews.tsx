import { Section } from "../Section";
import { motion } from "framer-motion";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Link } from "react-router-dom";
import { ChefHat, Clock } from "lucide-react";
import { useTranslation } from "react-i18next";

const LatestNews = () => {
  const { t } = useTranslation(["home", "common"]);
  return (
    <Section
      title="Latest Updates"
      subtitle="News, Offers & Expert Insights"
      className="bg-muted/20"
    >
      <div className="grid md:grid-cols-2 gap-8">
        {/* News */}
        <div>
          <h3 className="text-2xl font-bold mb-6">{t("home:news.title")}</h3>
          <div className="space-y-4">
            {[1, 2].map((item) => (
              <motion.div
                key={item}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: item * 0.1 }}
                viewport={{ once: true }}
              >
                <Link to={`/news/${item}`}>
                  <Card className="hover:shadow-strong transition-all duration-300 hover:-translate-y-1 group">
                    <div className="flex gap-4">
                      <div className="w-32 aspect-video bg-muted rounded-lg overflow-hidden flex-shrink-0">
                        <img
                          src="/placeholder.svg"
                          alt="News"
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                      </div>
                      <div className="flex-1 py-2">
                        <Badge className="mb-2">News</Badge>
                        <h4 className="font-bold mb-1 group-hover:text-primary transition-colors">
                          Special Offer Alert
                        </h4>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          Latest promotion details...
                        </p>
                      </div>
                    </div>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Blog */}
        <div>
          <h3 className="text-2xl font-bold mb-6">From Our Blog</h3>
          <div className="space-y-4">
            {[1, 2].map((item) => (
              <motion.div
                key={item}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: item * 0.1 }}
                viewport={{ once: true }}
              >
                <Link to={`/blog/${item}`}>
                  <Card className="hover:shadow-strong transition-all duration-300 hover:-translate-y-1 group">
                    <div className="flex gap-4">
                      <div className="w-32 aspect-video bg-muted rounded-lg overflow-hidden flex-shrink-0">
                        <img
                          src="/placeholder.svg"
                          alt="Blog"
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                      </div>
                      <div className="flex-1 py-2">
                        <div className="flex items-center gap-2 mb-2">
                          <ChefHat className="h-4 w-4 text-primary" />
                          <Clock className="h-3 w-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">
                            8 min
                          </span>
                        </div>
                        <h4 className="font-bold mb-1 group-hover:text-primary transition-colors">
                          Cooking Tips
                        </h4>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          Expert advice on...
                        </p>
                      </div>
                    </div>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  );
};

export default LatestNews;
