import React from "react";
import { Section } from "../Section";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Link } from "react-router-dom";
import state from "../../assets/state.webp";

const AboutPreviewWithStats: React.FC = () => {
  const { t } = useTranslation(["about", "common"]);

  const stats = t("about:preview.stats", {
    returnObjects: true,
  }) as {
    years: { value: string; label: string };
    branches: { value: string; label: string };
    halal: { value: string; label: string };
  };

  return (
    <Section className="bg-gradient-to-br from-muted/30 to-background">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="grid items-center gap-12 md:grid-cols-2"
      >
        <div>
          <Badge className="mb-4">
            <Sparkles className="mr-2 h-3 w-3" />
            {t("about:preview.badge")}
          </Badge>

          <h2 className="mb-6 text-4xl font-bold">
            {t("about:preview.headline")}
          </h2>

          <p className="mb-6 text-lg leading-relaxed text-muted-foreground">
            {t("about:preview.text")}
          </p>

          <div className="mb-6 grid grid-cols-3 gap-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="mb-1 text-3xl font-bold text-primary">
                {stats.years.value}
              </div>
              <div className="text-sm text-muted-foreground">
                {stats.years.label}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="mb-1 text-3xl font-bold text-primary">
                {stats.branches.value}
              </div>
              <div className="text-sm text-muted-foreground">
                {stats.branches.label}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="mb-1 text-3xl font-bold text-primary">
                {stats.halal.value}
              </div>
              <div className="text-sm text-muted-foreground">
                {stats.halal.label}
              </div>
            </motion.div>
          </div>

          <Button asChild>
            <Link to="/about">{t("about:preview.cta")}</Link>
          </Button>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="h-[450px] overflow-hidden rounded-2xl bg-muted shadow-strong"
        >
          <img
            src={state}
            alt={t("about:hero.title")}
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </motion.div>
      </motion.div>
    </Section>
  );
};

export default AboutPreviewWithStats;
