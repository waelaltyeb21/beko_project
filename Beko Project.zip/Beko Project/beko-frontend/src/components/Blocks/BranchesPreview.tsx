import { Section } from "../Section";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { MapPin } from "lucide-react";
import { Button } from "../ui/button";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import useFetch from "@/hooks/useFetch";
import { useLanguage } from "@/hooks/useLanguage";
import Loading from "../Loading";

export const sudanStates = {
  الخرطوم: "Khartoum",
  "البحر الاحمر": "Red Sea",
  الجزيرة: "Al Jazirah",
  القضارف: "Gedaref",
  كسلا: "Kassala",
  "نهر النيل": "River Nile",
  الشمالية: "Northern",
  سنار: "Sennar",
  "النيل الأزرق": "Blue Nile",
  "النيل الأبيض": "White Nile",
  "شمال كردفان": "North Kordofan",
  "جنوب كردفان": "South Kordofan",
  "شمال دارفور": "North Darfur",
  "جنوب دارفور": "South Darfur",
  "غرب دارفور": "West Darfur",
};

const BranchesPreview = () => {
  const { t } = useTranslation(["home", "common"]);
  const { currentLanguage } = useLanguage();
  const { data: branches = [], isLoading } = useFetch("/branches/all-branches");

  if (isLoading) return <Loading />;
  if (branches?.length === 0) return null;

  return (
    <Section
      title={t("home:branches.title")}
      subtitle={t("home:branches.subtitle")}
      className="bg-muted/20"
    >
      <div className="grid md:grid-cols-3 gap-8">
        {branches &&
          branches?.map((branch: any, index: number) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ y: -8 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="hover:shadow-strong transition-all h-full">
                <CardHeader className="flex flex-row items-center gap-4">
                  <div className="w-14 h-14 mb-4 rounded-xl bg-primary/10 flex items-center justify-center">
                    <MapPin className="h-7 w-7 text-primary" />
                  </div>
                  <CardTitle className="text-2xl">
                    {currentLanguage == "ar"
                      ? branch.state
                      : `${sudanStates[branch.state] || branch.state} State`}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                    asChild
                  >
                    <Link
                      to={`/branches#${`${
                        sudanStates[branch.state] || branch.state
                      }`
                        .replace(/\s+/g, "-")
                        .toLowerCase()}`}
                    >
                      {t("common:cta.viewAllBranches")}
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
      </div>
    </Section>
  );
};

export default BranchesPreview;
