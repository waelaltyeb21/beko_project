import React from "react";
import { Button } from "../ui/button";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { useTranslation } from "react-i18next";

const NetworkCoverage: React.FC = () => {
  const { t } = useTranslation("home");

  return (
    <section className="bg-muted/50 py-20">
      <div className="container mx-auto px-4 text-center">
        <h2 className="mb-4 text-3xl font-bold md:text-4xl">
          {t("networkCoverage.title")}
        </h2>

        <p className="mx-auto mb-8 max-w-2xl text-lg text-muted-foreground">
          {t("networkCoverage.subtitle")}
        </p>

        <div className="flex flex-col justify-center gap-4 sm:flex-row">
          <Button asChild size="lg">
            <Link to="/branches">
              {t("networkCoverage.viewBranches")}
              <ArrowRight className="ms-2 h-4 w-4" />
            </Link>
          </Button>

          <Button asChild size="lg" variant="outline">
            <Link to="/distributors">{t("networkCoverage.becomeDealer")}</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default NetworkCoverage;
