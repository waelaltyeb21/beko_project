import { motion } from "framer-motion";
import { Section } from "../Section";
import { Package, ShieldCheck, Snowflake, TrendingUp } from "lucide-react";
import { useTranslation } from "react-i18next";

const iconMap: Record<
  string,
  React.ComponentType<React.SVGProps<SVGSVGElement>>
> = {
  sourcing: Package,
  processing: ShieldCheck,
  preservation: Snowflake,
  delivery: TrendingUp,
};

const ProcessSection = () => {
  const { t } = useTranslation("home"); // غيّر "home" لو namespace مختلف

  const steps = t("processSection.steps", {
    returnObjects: true,
  }) as {
    key: string;
    title: string;
    description: string;
  }[];

  return (
    <Section
      title={t("processSection.title")}
      subtitle={t("processSection.subtitle")}
      className="bg-gradient-to-br from-background to-muted/30"
    >
      <div className="mx-auto max-w-4xl">
        <div className="grid gap-6 md:grid-cols-4">
          {steps.map((step, index) => {
            const Icon = iconMap[step.key] ?? Package;

            return (
              <motion.div
                key={step.key}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="relative text-center"
              >
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/20">
                  <Icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="mb-2 text-lg font-bold">{step.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {step.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </Section>
  );
};

export default ProcessSection;
