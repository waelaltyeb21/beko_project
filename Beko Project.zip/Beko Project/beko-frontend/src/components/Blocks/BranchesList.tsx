import { Card, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { MapPin } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import { sudanStates } from "./BranchesPreview";
import { Link, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Loading from "../Loading";

const BranchesList = ({ data, loading }) => {
  const { hash } = useLocation();

  useEffect(() => {
    if (!hash) return;
    const id = hash.replace("#", "");
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({
        behavior: "smooth",
      });
    }
  }, [hash]);

  const { currentLanguage } = useLanguage();
  const StatusVariants = {
    soon: "bg-blue-100 text-blue-700 hover:bg-blue-100",
    open: "bg-green-100 text-green-700 hover:bg-green-100",
    closed: "bg-red-100 text-red-700 hover:bg-red-100",
  };

  const StatusTranslate = {
    soon: "قريبا",
    open: "مفتوح",
    closed: "مغلق",
  };

  if (loading) return <Loading />;
  return (
    <div className="py-20">
      {data.map((state: any) => (
        <section
          key={state.state}
          id={
            sudanStates[state.state]?.replace(/\s+/g, "-").toLowerCase() ||
            state.state.toLowerCase()
          }
        >
          <div key={state.id} className="container mx-auto px-4 py-10">
            <h3 className="font-bold lg:text-5xl md:text-4xl text-3xl text-center mb-8">
              {currentLanguage == "ar" ? state.state : sudanStates[state.state]}
            </h3>

            <div className="">
              {state.cities.map((city: any, index: number) => (
                <div className="" key={city.en || index}>
                  <h4 className="font-bold lg:text-3xl text-2xl text-center mb-8">
                    <q>{city.city[currentLanguage]}</q>
                  </h4>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mx-16">
                    {city.branches.map((branch: any, idx: number) => (
                      <Link
                        key={branch.id}
                        to={branch?.mapsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Card className="hover-lift">
                          <CardHeader>
                            <Badge
                              className={`w-fit mb-2 ${
                                StatusVariants[branch.status]
                              }`}
                              variant="secondary"
                            >
                              {StatusTranslate[branch.status]}
                            </Badge>
                            <CardTitle>
                              {branch.name[currentLanguage]}
                            </CardTitle>
                            <CardDescription className="text-blue-500 flex items-start gap-2 pt-2">
                              <MapPin className="h-4 w-4 flex-shrink-0 mt-0.5" />
                              <span>{branch.address[currentLanguage]}</span>
                            </CardDescription>
                          </CardHeader>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      ))}
    </div>
  );
};

export default BranchesList;
