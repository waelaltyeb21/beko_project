import { motion } from "framer-motion";
import { Section } from "../Section";
import { Card, CardContent, CardDescription, CardHeader } from "../ui/card";
import { Heart, Star } from "lucide-react";
import { useTranslation } from "react-i18next";

const Testimonials = () => {
  const { t } = useTranslation(["home"]);

  const testimonials = t("testimonials.items", {
    returnObjects: true,
  }) as Array<{
    name: string;
    location: string;
    text: string;
  }>;
  return (
    <Section
      title={t("testimonials.title")}
      subtitle={t("testimonials.subtitle")}
      className="bg-gradient-to-br from-muted/30 to-background"
    >
      <div className="grid md:grid-cols-3 gap-8">
        {testimonials?.map((item: any, index: number) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            whileHover={{ y: -8 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            viewport={{ once: true }}
          >
            <Card className="hover:shadow-strong transition-all h-full">
              <CardHeader>
                <div className="flex gap-2 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-5 w-5 fill-primary text-primary"
                    />
                  ))}
                </div>
                <CardDescription className="text-base leading-relaxed italic">
                  {item.text}
                </CardDescription>
              </CardHeader>

              <CardContent>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Heart className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">{item.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {item.location}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};

export default Testimonials;
