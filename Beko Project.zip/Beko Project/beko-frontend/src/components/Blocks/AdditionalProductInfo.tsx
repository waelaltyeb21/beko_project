import { CheckCircle2 } from "lucide-react";
import { useTranslation } from "react-i18next";

const AdditionalProductInfo = () => {
  const { t } = useTranslation("products");
  const features = [
    {
      key: "freshSafe",
      defaultTitle: "Fresh & Safe",
      defaultDesc: "Maintained cold chain from production to delivery",
    },
    {
      key: "qualityTested",
      defaultTitle: "Quality Tested",
      defaultDesc: "Every batch undergoes rigorous quality checks",
    },
    {
      key: "hygienicProcessing",
      defaultTitle: "Hygienic Processing",
      defaultDesc: "Advanced equipment and strict sanitation",
    },
    {
      key: "versatileOptions",
      defaultTitle: "Versatile Options",
      defaultDesc: "Wide range to suit all cooking needs",
    },
    {
      key: "consistentQuality",
      defaultTitle: "Consistent Quality",
      defaultDesc: "Same high standard in every package",
    },
    {
      key: "affordablePrices",
      defaultTitle: "Affordable Prices",
      defaultDesc: "Premium quality at competitive prices",
    },
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            {t("additionalInfo.title", "What Makes Our Products Special")}
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {features.map((item) => (
              <div
                key={item.key}
                className="flex gap-4 p-6 bg-muted/50 rounded-lg"
              >
                <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg mb-1">
                    {t(
                      `additionalInfo.features.${item.key}.title`,
                      item.defaultTitle
                    )}
                  </h3>
                  <p className="text-muted-foreground">
                    {t(
                      `additionalInfo.features.${item.key}.description`,
                      item.defaultDesc
                    )}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AdditionalProductInfo;
