import { Section } from "../Section";
import { Card, CardHeader, CardTitle } from "../ui/card";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import { Badge } from "../ui/badge";
import useFetch from "@/hooks/useFetch";
import { ThumbImage } from "@/pages/News";
import { Youtube } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import Loading from "../Loading";

const RelatedBlogs = () => {
  const { t } = useTranslation();
  const { currentLanguage } = useLanguage();
  const { data, isLoading, error } = useFetch("/blogs");

  if (isLoading) return <Loading />;
  if (error) return null;
  if (data?.blogs?.length === 0) return null;
  return (
    <Section
      title={t("news:related.title")}
      subtitle={t("news:related.subtitle")}
      className="bg-muted/20"
    >
      <div className="grid md:grid-cols-3 gap-6">
        {data?.blogs?.map((blog: any, index: number) => (
          <motion.div
            key={blog?.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            viewport={{ once: true }}
          >
            <Link to={`/news/${blog?.slug}`}>
              <Card className="hover:shadow-strong transition-all duration-300 hover:-translate-y-2 h-full group">
                <div className="relative aspect-video bg-muted overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center bg-black/50 group-hover:bg-black/30 transition-colors">
                    <Youtube className="h-16 w-16 text-white opacity-90" />
                  </div>
                  <img
                    src={ThumbImage(blog?.videoUrl)!}
                    alt="Related Post"
                    className="w-full h-full object-cover transition-transform duration-700"
                  />
                </div>
                <CardHeader>
                  <Badge className="w-fit mb-2" variant="outline">
                    {new Date().toLocaleDateString()}
                  </Badge>
                  <CardTitle className="text-lg group-hover:text-primary transition-colors">
                    {blog?.title[currentLanguage]}
                  </CardTitle>
                </CardHeader>
              </Card>
            </Link>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};

export default RelatedBlogs;
