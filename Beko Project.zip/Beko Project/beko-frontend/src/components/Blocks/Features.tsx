import React from "react";
import { Card, CardDescription, CardHeader, CardTitle } from "../ui/card";
import {
  Award,
  MapPin,
  Package,
  ShieldCheck,
  Truck,
  Users,
} from "lucide-react";
import { useTranslation } from "react-i18next";

const iconMap: Record<
  string,
  React.ComponentType<React.SVGProps<SVGSVGElement>>
> = {
  qualityAssurance: ShieldCheck,
  coldChain: Truck,
  range: Package,
  team: Users,
  certified: Award,
  nationwide: MapPin,
};

const Features: React.FC = () => {
  const { t } = useTranslation("home");

  const items = t("featuresSection.items", {
    returnObjects: true,
  }) as {
    key: string;
    title: string;
    description: string;
  }[];

  return (
    <section className="bg-muted/50 py-20">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold md:text-4xl">
            {t("featuresSection.title")}
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            {t("featuresSection.subtitle")}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {items.map((feature) => {
            const Icon = iconMap[feature.key] ?? ShieldCheck;

            return (
              <Card key={feature.key} className="hover-lift">
                <CardHeader>
                  <Icon className="mb-4 h-12 w-12 text-primary" />
                  <CardTitle>{feature.title}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;
