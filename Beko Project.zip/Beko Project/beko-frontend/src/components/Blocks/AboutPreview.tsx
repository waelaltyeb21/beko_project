import { Button } from "../ui/button";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { useTranslation } from "react-i18next";
import image from "@/assets/about-image.webp";

const AboutPreview = () => {
  const { t } = useTranslation(["about", "common"]);
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              {t("about:hero.title")}
            </h2>
            <p className="text-lg text-muted-foreground mb-4 leading-relaxed">
              {t("about:intro.intro")}
            </p>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              {t("about:intro.description")}
            </p>
            <Button asChild>
              <Link to="/about">
                {t("common:learnMore")}{" "}
                <ArrowUpRight className="ms-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="relative h-[450px] rounded-xl overflow-hidden shadow-xl">
            <img
              src={image}
              alt="Beko facility"
              loading="lazy"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutPreview;
