import { motion } from "framer-motion";
import { Section } from "../Section";
import { TrendingUp, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { HeroButton } from "../ui/button-variants";

const DealersCTA = () => {
  const { t } = useTranslation(["home", "common"]);

  const benefits = t("home:dealers.benefits", {
    returnObjects: true,
  }) as string[];

  return (
    <Section className="bg-gradient-to-br from-primary via-primary to-beko-blue-dark text-primary-foreground relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
      </div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="max-w-4xl mx-auto text-center relative z-10"
      >
        <Users className="h-20 w-20 mx-auto mb-8 opacity-90" />
        <h2 className="text-4xl md:text-5xl font-bold mb-6">
          {t("home:dealers.title")}
        </h2>
        <p className="text-xl md:text-2xl mb-10 opacity-90">
          {t("home:dealers.subtitle")}
        </p>
        <div className="grid md:grid-cols-2 gap-6 mb-10 text-left max-w-2xl mx-auto">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="flex items-start gap-3 bg-white/10 p-4 rounded-lg"
            >
              <TrendingUp className="h-5 w-5 mt-1 flex-shrink-0" />
              <span className="text-lg">{benefit}</span>
            </motion.div>
          ))}
        </div>
        <HeroButton variant="hero" size="lg" asChild>
          <Link to="/dealers">{t("common:cta.apply")}</Link>
        </HeroButton>
      </motion.div>
    </Section>
  );
};

export default DealersCTA;
