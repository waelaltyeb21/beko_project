import { motion } from "framer-motion";
import { Plus, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  image: string;
  discription?: string;
  isRTL?: boolean;
  onAddToCart: () => void;
}

export const ProductCard = ({
  id,
  name,
  price,
  image,
  discription,
  isRTL = false,
  onAddToCart,
}: ProductCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      viewport={{ once: true }}
      className="group relative"
    >
      <div className="relative bg-card rounded-2xl overflow-hidden border border-border/50 hover:border-primary/30 transition-all duration-500 hover:shadow-2xl hover:shadow-primary/10">
        {/* Image Container */}
        <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-muted/50 to-muted">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110"
          />

          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          {/* Quick Add Button */}
          <motion.div
            className="absolute bottom-4 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300"
            initial={false}
          >
            <Button
              onClick={onAddToCart}
              size="sm"
              className="gap-2 rounded-full px-6 shadow-lg bg-primary hover:bg-primary/90"
            >
              <ShoppingBag className="h-4 w-4" />
              <span className="text-sm font-medium">Add</span>
            </Button>
          </motion.div>

          {/* Weight Badge */}
          <div className="absolute top-3 right-3">
            <span className="px-3 py-1.5 text-xs font-semibold bg-background/90 backdrop-blur-sm text-foreground rounded-full border border-border/50">
              {"1KG"}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 space-y-3">
          <h3 className="font-semibold text-foreground text-lg leading-tight line-clamp-1 group-hover:text-primary transition-colors duration-300">
            {name}
          </h3>

          <p className="text-gray-600 text-sm">{discription}</p>

          <div className="flex items-center justify-between">
            <p className="text-2xl font-bold text-primary">
              {price.toLocaleString()}
              <span className="text-sm font-normal text-muted-foreground ml-1">
                SDG
              </span>
            </p>

            <Button
              variant="ghost"
              size="icon"
              onClick={onAddToCart}
              className="h-10 w-10 rounded-full bg-primary/10 hover:bg-primary hover:text-primary-foreground transition-all duration-300 group-hover:scale-110"
            >
              <Plus className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
