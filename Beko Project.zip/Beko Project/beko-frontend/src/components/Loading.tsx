import { useTranslation } from "react-i18next";
import { Spinner } from "./ui/spinner";
import { motion } from "framer-motion";

const Loading = () => {
  const { t } = useTranslation("common");

  return (
    <section className="flex flex-col gap-6 justify-center items-center min-h-[60dvh] bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Animated Glow Ring */}
      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="relative"
      >
        {/* <div className="absolute inset-0 rounded-full blur-2xl bg-blue-400/30 animate-pulse" /> */}
        <Spinner className="relative size-14 text-blue-600" />
      </motion.div>

      {/* Loading Text */}
      <motion.h1
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.3 }}
        className="text-lg font-semibold tracking-wide text-slate-700"
      >
        {t("loading")}
      </motion.h1>

      {/* Subtle hint text */}
      {/* <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-sm text-slate-500"
      >
        Please wait while we prepare your data
      </motion.p> */}

      {/* Accessibility */}
      <span className="sr-only">Loading...</span>
    </section>
  );
};

export default Loading;
