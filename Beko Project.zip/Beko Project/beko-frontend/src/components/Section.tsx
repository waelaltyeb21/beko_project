import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { cn } from '@/lib/utils';

interface SectionProps {
  title?: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
  containerClassName?: string;
}

export const Section = ({ title, subtitle, children, className, containerClassName }: SectionProps) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className={cn("py-16 md:py-24", className)}>
      <div className={cn("container mx-auto", containerClassName)}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          {(title || subtitle) && (
            <div className="text-center mb-12">
              {subtitle && (
                <p className="text-sm md:text-base font-medium text-primary mb-2 uppercase tracking-wide">
                  {subtitle}
                </p>
              )}
              {title && (
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground">
                  {title}
                </h2>
              )}
            </div>
          )}
          {children}
        </motion.div>
      </div>
    </section>
  );
};
