import { useScrollToTop } from "@/hooks/useScrollToTop";

export const ScrollToTop = () => {
  useScrollToTop();

  return null;
};
