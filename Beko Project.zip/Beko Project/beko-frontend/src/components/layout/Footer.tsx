import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import {
  Facebook,
  Instagram,
  Twitter,
  Mail,
  Phone,
  MapPin,
  Youtube,
} from "lucide-react";

export const Footer = () => {
  const { t } = useTranslation("common");
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { to: "/", label: t("nav.home") },
    { to: "/about", label: t("nav.about") },
    { to: "/products", label: t("nav.products") },
    { to: "/branches", label: t("nav.branches") },
    { to: "/dealers", label: t("nav.dealers") },
    { to: "/news", label: t("nav.offersNews") },
    { to: "/contact", label: t("nav.contact") },
  ];

  return (
    <footer className="bg-primary text-white border-t">
      <div className="container mx-auto py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold">{t("footer.about")}</h3>
            <p className="text-sm">{t("footer.aboutText")}</p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold">{t("footer.quickLinks")}</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-sm hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold">{t("footer.contact")}</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>{t("footer.address")}</span>
              </li>
              <li className="flex items-start gap-2 text-sm">
                <Phone className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <Link to="tel:249914699997" dir="ltr">
                  249914699997
                </Link>
              </li>
              <li className="flex items-start gap-2 text-sm">
                <Phone className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <Link to="tel:249123328125" dir="ltr">
                  249123328125
                </Link>
              </li>
              <li className="flex items-start gap-2 text-sm">
                <Phone className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <Link to="tel:249924699997" dir="ltr">
                  249924699997
                </Link>
              </li>
              {/* <li className="flex items-start gap-2 text-sm">
                <Mail className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <Link to="tel:">{t("footer.email")}</Link>
              </li> */}
            </ul>
          </div>

          {/* Social Media */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold">{t("footer.followUs")}</h3>
            <div className="flex gap-4">
              <Link
                to="https://www.facebook.com/share/1AUgMXeKL5/"
                target="_blank"
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full bg-primary/10 hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </Link>
              <Link
                to="https://youtube.com/@beko_meat_products?si=kfGZwywtEuq_BlPN"
                target="_blank"
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full bg-primary/10 hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Youtube className="h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-border/60">
          <p className="text-center text-sm">
            {t("footer.copyright", { year: currentYear })}
            {" - "}
            {`${currentYear}©`}
          </p>
        </div>
      </div>
    </footer>
  );
};
