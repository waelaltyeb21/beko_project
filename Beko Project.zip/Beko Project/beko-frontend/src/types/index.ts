export interface LocalizedString {
  en: string;
  ar: string;
}

export interface Product {
  id: string;
  slug: string;
  name: LocalizedString;
  description: LocalizedString;
  category: string;
  weights: string[];
  images: string[];
  available: boolean;
  nutritionInfo?: LocalizedString;
}

export interface Branch {
  id: string;
  name: LocalizedString;
  state: LocalizedString;
  city: LocalizedString;
  address: LocalizedString;
  phone?: string;
  email?: string;
  hours?: LocalizedString;
}

export interface NewsPost {
  id: string;
  slug: string;
  title: LocalizedString;
  excerpt: LocalizedString;
  content: LocalizedString;
  date: string;
  youtubeId?: string;
  image: string;
  type: 'news' | 'offer';
  tags: string[];
}

export interface DealerApplication {
  businessName: string;
  ownerName: string;
  phone: string;
  email: string;
  city: string;
  address: string;
  experience: string;
  message?: string;
  commercialRegistration?: File;
}

export interface ContactForm {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

export type Language = 'en' | 'ar';
