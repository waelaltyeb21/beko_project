import { Suspense, lazy } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { Hero } from "@/components/Hero";
import { HeroButton } from "@/components/ui/button-variants";
import Loading from "@/components/Loading";
import hero_home from "@/assets/hero-home.webp";

// Lazy Loaded Blocks
const QualityAndSafety = lazy(
  () => import("@/components/Blocks/QualityAndSafety")
);
const Features = lazy(() => import("@/components/Blocks/Features"));
const BrandTagline = lazy(() => import("@/components/Blocks/BrandTagline"));
const AboutPreview = lazy(() => import("@/components/Blocks/AboutPreview"));
const ProductCategories = lazy(
  () => import("@/components/Blocks/ProductCategories")
);
const NetworkCoverage = lazy(
  () => import("@/components/Blocks/NetworkCoverage")
);
const VisionStatement = lazy(
  () => import("@/components/Blocks/VisionStatement")
);
const DealersCTA = lazy(() => import("@/components/Blocks/DealersCTA"));
const ProcessSection = lazy(() => import("@/components/Blocks/ProcessSection"));
const Testimonials = lazy(() => import("@/components/Blocks/Testimonials"));
// const SpecialOfferVideo = lazy(
//   () => import("@/components/Blocks/SpecialOfferVideo")
// );
const BranchesPreview = lazy(
  () => import("@/components/Blocks/BranchesPreview")
);
const AboutPreviewWithStats = lazy(
  () => import("@/components/Blocks/AboutPreviewWithStats")
);
const Stats = lazy(() => import("@/components/Blocks/Stats"));
const RelatedBlogs = lazy(() => import("@/components/Blocks/RelatedBlogs"));

export default function Home() {
  const { t } = useTranslation(["home", "common"]);

  return (
    <div className="min-h-screen">
      {/* Hero (Not Lazy – Critical Content) */}
      <Hero
        title={t("home:hero.title")}
        subtitle={t("home:hero.subtitle")}
        description={t("home:hero.description")}
        imageUrl={hero_home}
      >
        <HeroButton variant="hero" size="lg" asChild>
          <Link to="/products">{t("common:cta.viewProducts")}</Link>
        </HeroButton>
        <HeroButton variant="heroOutline" size="lg" asChild>
          <Link to="/dealers">{t("common:cta.becomeDealer")}</Link>
        </HeroButton>
      </Hero>

      {/* Lazy Content */}
      <Suspense fallback={<Loading />}>
        <BrandTagline />
        <Stats />
        <AboutPreviewWithStats />
        <ProductCategories />
        <AboutPreview />
        <QualityAndSafety />
        <Features />
        <NetworkCoverage />
        <VisionStatement />
        {/* <SpecialOfferVideo /> */}
        <ProcessSection />
        <BranchesPreview />
        <DealersCTA />
        <RelatedBlogs />
        <Testimonials />
      </Suspense>
    </div>
  );
}
