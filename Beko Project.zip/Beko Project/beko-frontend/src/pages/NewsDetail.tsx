import { useParams, Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Section } from "@/components/Section";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, ArrowLeft } from "lucide-react";
import useFetch from "@/hooks/useFetch";
import { useLanguage } from "@/hooks/useLanguage";
import { ExtractEmbdedURL, ThumbImage } from "./News";
import TipTapEditor from "@/components/Editor/TipTapEditor";
import Loading from "@/components/Loading";

export default function NewsDetail() {
  const { id } = useParams();
  const { t } = useTranslation(["news", "common"]);
  const { currentLanguage } = useLanguage();
  const { data, isLoading, error } = useFetch(`/blogs/${id}`);

  if (isLoading) return <Loading />;
  if (error) return null;
  return (
    <div className="min-h-screen bg-background">
      {/* Hero with YouTube Video */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="relative bg-muted"
      >
        <div className="container mx-auto py-12">
          <div className="max-w-5xl mx-auto">
            {data?.blog.videoUrl && (
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="aspect-video rounded-2xl overflow-hidden shadow-strong mb-8"
              >
                <iframe
                  className="w-full h-full"
                  src={ExtractEmbdedURL(data?.blog?.videoUrl).fullURL}
                  title="YouTube video"
                  allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </motion.div>
            )}
          </div>
        </div>
      </motion.div>

      {/* Content */}
      <Section>
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            {/* Back Button */}
            <Button variant="ghost" asChild className="mb-6">
              <Link to="/news">
                <ArrowLeft className="mr-2 h-4 w-4" />
                {t("common:cta.back")}
              </Link>
            </Button>

            {/* Post Header */}
            <Card className="mb-8 shadow-strong">
              <CardHeader className="space-y-6">
                <Badge
                  className="w-fit"
                  variant={
                    data?.blog.type === "offer" ? "default" : "secondary"
                  }
                >
                  {data?.blog.type === "offer"
                    ? t("news:filter.offers")
                    : t("news:filter.news")}
                </Badge>

                <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                  {data?.blog.title[currentLanguage]}
                </h1>

                {/* Meta Information */}
                <div className="flex flex-wrap items-center gap-6 text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span>
                      {new Date(data?.blog.createdAt).toLocaleDateString(
                        "ar-SD",
                        {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        }
                      )}
                    </span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="prose prose-lg max-w-none dark:prose-invert border-t">
                {data?.blog?.content && (
                  <TipTapEditor content={data?.blog?.content} />
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </Section>

      {/* Related News */}
      {data?.latestBlogs?.length !== 0 && (
        <Section title={t("news:related.title")} className="bg-muted/20">
          <div className="grid md:grid-cols-3 gap-6">
            {data?.latestBlogs?.map((blog: any, index: number) => (
              <motion.div
                key={blog.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Link to={`/news/${blog.id}`}>
                  <Card className="hover:shadow-strong transition-all duration-300 hover:-translate-y-2 h-full">
                    <div className="aspect-video bg-muted">
                      <img
                        src={ThumbImage(blog.videoUrl)}
                        alt={blog.title[currentLanguage]}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        {blog.title[currentLanguage]}
                      </CardTitle>
                    </CardHeader>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </Section>
      )}

      {/* CTA */}
      <Section className="bg-gradient-to-br from-primary to-beko-blue-light text-primary-foreground">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <h2 className="text-4xl font-bold mb-4">{t("news:cta.title")}</h2>
          <p className="text-xl mb-8 opacity-90">{t("news:cta.subtitle")}</p>
          <Button variant="secondary" size="lg" asChild>
            <Link to="/contact">{t("news:cta.button")}</Link>
          </Button>
        </motion.div>
      </Section>
    </div>
  );
}
