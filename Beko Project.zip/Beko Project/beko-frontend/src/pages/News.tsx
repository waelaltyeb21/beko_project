import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Youtube, Sparkles } from "lucide-react";
import useFetch from "@/hooks/useFetch";
import { useLanguage } from "@/hooks/useLanguage";
import BlogsPagination from "@/components/Blocks/BlogsPagination";
import Loading from "@/components/Loading";
import hero_news from "@/assets/hero-news.webp";

export const ExtractEmbdedURL = (
  url: string
): { videoId: string; fullURL: string } | null => {
  try {
    const parsed = new URL(url);
    let videoId = "";

    if (parsed.searchParams.get("v")) {
      videoId = parsed.searchParams.get("v")!;
    }

    if (!videoId && parsed.hostname.includes("youtu.be")) {
      videoId = parsed.pathname.replace("/", "");
    }

    if (!videoId && parsed.pathname.startsWith("/embed/")) {
      videoId = parsed.pathname.split("/embed/")[1];
    }

    if (!videoId && parsed.pathname.startsWith("/shorts/")) {
      videoId = parsed.pathname.split("/shorts/")[1];
    }

    if (!videoId && parsed.pathname.startsWith("/v/")) {
      videoId = parsed.pathname.split("/v/")[1];
    }

    if (!videoId) return null;

    return {
      videoId,
      fullURL: `https://www.youtube.com/embed/${videoId}`,
    };
  } catch {
    return null;
  }
};

export const ThumbImage = (url: string): string | null => {
  try {
    const { videoId } = ExtractEmbdedURL(url || "");
    return `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
  } catch (error) {
    return "/placeholder.svg";
  }
};

export default function News() {
  const { t } = useTranslation(["news", "common"]);
  const { currentLanguage } = useLanguage();
  const [page, setPage] = useState(1);
  const { data, isLoading, refetch } = useFetch(`/blogs`);

  const handleFilters = async (key: string, value: any) => {
    if (key === "page") setPage(value);
    await refetch({ url: `/blogs?page=${value}` });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <Hero
        title={t("news:hero.title")}
        subtitle={t("news:hero.subtitle")}
        imageUrl={hero_news}
      />

      {/* 3. News & Offers Grid */}
      {isLoading ? (
        <Loading />
      ) : data?.blogs && data?.blogs?.length === 0 ? (
        <Section>
          <div className="text-center py-20">
            <Sparkles className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
            <h2 className="text-2xl md:text-3xl font-bold mb-2">
              {t("news:latest.empty")}
            </h2>
          </div>
        </Section>
      ) : (
        <Section
          title={t("news:latest.title")}
          subtitle={t("news:latest.subtitle")}
        >
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {data?.blogs?.map((blog: any, index: number) => (
              <motion.div
                key={blog?.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Link to={`/news/${blog.id}`}>
                  <Card className="overflow-hidden hover:shadow-strong transition-all duration-300 hover:-translate-y-2 h-full flex flex-col group">
                    {blog?.videoUrl ? (
                      <div className="aspect-video bg-muted relative overflow-hidden">
                        <div className="absolute inset-0 flex items-center justify-center bg-black/50 group-hover:bg-black/30 transition-colors">
                          <Youtube className="h-16 w-16 text-white opacity-90" />
                        </div>
                        <img
                          src={ThumbImage(blog?.videoUrl)!}
                          alt={blog?.title[currentLanguage]}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="aspect-video bg-muted overflow-hidden">
                        <img
                          src="/placeholder.svg"
                          alt={blog?.title[currentLanguage]}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        />
                      </div>
                    )}
                    <CardHeader className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge
                          variant={
                            blog?.type === "offer" ? "default" : "secondary"
                          }
                        >
                          {blog?.type === "offer"
                            ? t("news:filter.offers")
                            : t("news:filter.news")}
                        </Badge>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4 mr-1" />
                          {new Date(blog?.createdAt).toLocaleDateString(
                            undefined,
                            {
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                            }
                          )}
                        </div>
                      </div>
                      <CardTitle className="group-hover:text-primary transition-colors">
                        {blog?.title[currentLanguage]}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <Button variant="link" className="p-0">
                        {t("common:cta.readMore")}
                      </Button>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>

          <BlogsPagination meta={data?.meta} handleFilters={handleFilters} />
        </Section>
      )}

      {/* 4. YouTube Video Embed Example */}
      {data?.blogs[0]?.videoUrl && (
        <Section className="bg-muted/20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="max-w-5xl mx-auto"
          >
            <Card className="overflow-hidden shadow-strong">
              <CardContent className="p-0">
                <div className="aspect-video bg-muted overflow-hidden">
                  <iframe
                    className="w-full h-full"
                    src={ExtractEmbdedURL(data?.blogs[0]?.videoUrl).fullURL}
                    title="YouTube video"
                    allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
                <div className="p-8">
                  <Badge className="mb-4">
                    <Youtube className="h-4 w-4 mr-2" />
                    احدث منشور
                  </Badge>
                  <h3 className="text-3xl font-bold mb-3">
                    {data?.blogs[0]?.title[currentLanguage]}
                  </h3>
                  <p className="text-lg text-muted-foreground mb-4"></p>
                  <Button size="lg" asChild>
                    <Link to="/news/3">{t("common:cta.viewDetails")}</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </Section>
      )}

      {/* 8. CTA */}
      <Section className="bg-gradient-to-br from-primary via-primary to-beko-blue-dark text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center relative z-10"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            {t("news:cta.title")}
          </h2>
          <p className="text-xl md:text-2xl mb-10 opacity-90">
            {t("news:cta.subtitle")}
          </p>
          <Button
            variant="secondary"
            size="lg"
            className="shadow-strong"
            asChild
          >
            <Link to="/contact">{t("news:cta.button")}</Link>
          </Button>
        </motion.div>
      </Section>
    </div>
  );
}
