import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useCartStore } from "@/stores/cartStore";
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import { useTranslation } from "react-i18next";
import { NumberFormat } from "@/lib/NumberFormat";
import hero_cart from "@/assets/hero-cart.webp";

export default function Cart() {
  const { currentLanguage } = useLanguage();
  const { t } = useTranslation(["cart", "common"]);

  const { items, updateQuantity, removeItem, getTotalPrice, clearCart } =
    useCartStore();

  if (items.length === 0) {
    return (
      <div className="min-h-screen">
        <Hero
          title={t("cart:hero.title")}
          subtitle={t("cart:hero.subtitle")}
          imageUrl={hero_cart}
        />
        <Section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <ShoppingBag className="h-24 w-24 mx-auto mb-6 text-muted-foreground/50" />
            <h2 className="text-2xl font-bold mb-4">{t("cart:empty.title")}</h2>
            <p className="text-muted-foreground mb-8">
              {t("cart:empty.description")}
            </p>
            <Button size="lg" asChild>
              <Link to="/products">{t("cart:empty.cta")}</Link>
            </Button>
          </motion.div>
        </Section>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Hero
        title={t("cart:hero.title")}
        subtitle={t("cart:hero.subtitle")}
        imageUrl={hero_cart}
      />

      <Section>
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardContent className="p-0">
                    <div className="flex flex-col sm:flex-row">
                      <div className="w-full sm:w-40 lg:h-32 h-64 bg-muted">
                        <img
                          src={item.image}
                          alt={item[currentLanguage]}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      </div>
                      <div className="flex-1 p-4 flex flex-col sm:flex-row justify-between">
                        <div className="mb-4 sm:mb-0">
                          <h3 className="font-semibold text-lg">
                            {item.name[currentLanguage]}
                          </h3>
                          <p className="text-primary font-bold mt-2">
                            {NumberFormat(item.price)} SDG
                          </p>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-2 bg-muted rounded-lg p-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() =>
                                updateQuantity(item.id, item.quantity - 1)
                              }
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <span className="w-8 text-center font-semibold">
                              {item.quantity}
                            </span>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() =>
                                updateQuantity(item.id, item.quantity + 1)
                              }
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={() => removeItem(item.id)}
                          >
                            <Trash2 className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}

            <div className="flex justify-end">
              <Button variant="outline" onClick={clearCart}>
                {t("cart:clearCart")}
              </Button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="sticky top-24 border-2 border-primary/20">
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-6">
                    {t("cart:summary.title")}
                  </h2>

                  <div className="space-y-4 mb-6">
                    {items.map((item) => (
                      <div
                        key={item.id}
                        className="flex justify-between text-sm"
                      >
                        <span className="text-muted-foreground">
                          {item[currentLanguage]} x{item.quantity}
                        </span>
                        <span>
                          {NumberFormat(item.price * item.quantity)} SDG
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="border-t pt-4 mb-6">
                    <div className="flex justify-between text-lg font-bold">
                      <span>{t("cart:summary.total")}</span>
                      <span className="text-primary">
                        {NumberFormat(getTotalPrice())} SDG
                      </span>
                    </div>
                  </div>

                  <Button size="lg" className="w-full" asChild>
                    <Link to="/checkout">
                      {t("cart:summary.checkout")}
                      <ArrowRight className="h-4 w-4 ms-2" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </Section>
    </div>
  );
}
