import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";

const NotFound = () => {
  const location = useLocation();
  const { t } = useTranslation('common');

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-muted/30 to-background">
      <div className="text-center px-4">
        <h1 className="mb-4 text-9xl font-bold text-primary">404</h1>
        <h2 className="mb-4 text-3xl font-semibold">{t('nav.home')}</h2>
        <p className="mb-8 text-xl text-muted-foreground max-w-md mx-auto">
          {t('siteName')}
        </p>
        <Button asChild size="lg">
          <Link to="/home">
            <Home className="mr-2 h-5 w-5" />
            {t('nav.home')}
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default NotFound;
