import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useCartStore } from "@/stores/cartStore";
import { useToast } from "@/hooks/use-toast";
import { MessageCircle, ShoppingBag, ArrowLeft, Package } from "lucide-react";
import { useForm } from "react-hook-form";
import { useLanguage } from "@/hooks/useLanguage";
import { NumberFormat } from "@/lib/NumberFormat";
import hero_cart from "@/assets/hero-checkout.webp";

type CheckoutForm = {
  name: string;
  address: string;
  phone: string;
};

export default function Checkout() {
  const { t } = useTranslation(["checkout", "common"]);
  const { items, getTotalPrice, clearCart } = useCartStore();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { currentLanguage } = useLanguage();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<CheckoutForm>();

  const onSubmit = (formData: CheckoutForm) => {
    const productsList = items
      .map(
        (item) =>
          `• ${item.name[currentLanguage]} x${item.quantity} = ${(
            item.price * item.quantity
          ).toFixed(2)} SDG`
      )
      .join("\n");

    const message = `🛒 *${t("checkout:whatsapp.newOrder")}*

📋 *${t("checkout:whatsapp.customerInfo")}*
${t("checkout:form.name")}: ${formData.name}
${t("checkout:form.address")}: ${formData.address}
${t("checkout:form.phone")}: ${formData.phone}

📦 *${t("checkout:whatsapp.products")}*
${productsList}

💰 *${t("checkout:whatsapp.total")}*: ${getTotalPrice().toFixed(2)} SDG`;

    const encodedMessage = encodeURIComponent(message);
    const phoneNumber = "249914699997";
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;

    window.open(whatsappUrl, "_blank");

    toast({
      title: t("checkout:success.title"),
      description: t("checkout:success.description"),
    });

    clearCart();
    navigate("/products");
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen">
        <Hero
          title={t("checkout:hero.title")}
          subtitle={t("checkout:hero.subtitle")}
          imageUrl={hero_cart}
        />
        <Section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <ShoppingBag className="h-24 w-24 mx-auto mb-6 text-muted-foreground/50" />
            <h2 className="text-2xl font-bold mb-4">
              {t("checkout:empty.title")}
            </h2>
            <p className="text-muted-foreground mb-8">
              {t("checkout:empty.description")}
            </p>
            <Button size="lg" asChild>
              <Link to="/products">{t("checkout:empty.cta")}</Link>
            </Button>
          </motion.div>
        </Section>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Hero
        title={t("checkout:hero.title")}
        subtitle={t("checkout:hero.subtitle")}
        imageUrl={hero_cart}
      />

      <Section>
        <div className="max-w-4xl mx-auto">
          <Button variant="ghost" asChild className="mb-6">
            <Link to="/cart">
              <ArrowLeft className="h-4 w-4 me-2" />
              {t("checkout:backToCart")}
            </Link>
          </Button>

          <div className="grid md:grid-cols-2 gap-8">
            {/* ✅ Checkout Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <Card className="border-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="h-5 w-5 text-green-500" />
                    {t("checkout:form.title")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                    <div>
                      <Label>{t("checkout:form.name")} *</Label>
                      <Input
                        {...register("name", { required: true, minLength: 2 })}
                        className={errors.name ? "border-destructive" : ""}
                      />
                      {errors.name && (
                        <p className="text-sm text-destructive">الاسم مطلوب</p>
                      )}
                    </div>

                    <div>
                      <Label>{t("checkout:form.address")} *</Label>
                      <Input
                        {...register("address", {
                          required: true,
                        })}
                        className={errors.address ? "border-destructive" : ""}
                      />
                      {errors.address && (
                        <p className="text-sm text-destructive">
                          {currentLanguage === "ar"
                            ? "العنوان مطلوب"
                            : "Address is required"}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label>{t("checkout:form.phone")} *</Label>
                      <Input
                        {...register("phone", { required: true, minLength: 9 })}
                        className={errors.phone ? "border-destructive" : ""}
                      />
                      {errors.phone && (
                        <p className="text-sm text-destructive">رقم غير صحيح</p>
                      )}
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      <MessageCircle className="h-5 w-5 me-2" />
                      {t("checkout:form.submit")}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* ✅ Order Summary */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="border-2 border-primary/20 sticky top-24">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-primary" />
                    {t("checkout:summary.title")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 mb-6">
                    {items.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg"
                      >
                        <img
                          src={item.image}
                          alt={item.name[currentLanguage]}
                          className="w-16 h-16 object-cover rounded-md"
                        />
                        <div className="flex-1">
                          <h4 className="font-semibold text-sm">
                            {item.name[currentLanguage]}
                          </h4>
                          {/* <p className="text-xs text-muted-foreground">
                            {item.weight} x{item.quantity}
                          </p> */}
                        </div>
                        <span className="font-bold text-primary">
                          {NumberFormat(item.price * item.quantity)} SDG
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex justify-between text-xl font-bold">
                      <span>{t("checkout:summary.total")}</span>
                      <span className="text-primary">
                        {NumberFormat(getTotalPrice())} SDG
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </Section>
    </div>
  );
}
