import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { Snowflake, Package, Scale, ShoppingCart } from "lucide-react";
import AdditionalProductInfo from "@/components/Blocks/AdditionalProductInfo";
import useFetch from "@/hooks/useFetch";
import { useLanguage } from "@/hooks/useLanguage";
import Loading from "@/components/Loading";
import { ProductCard } from "@/components/Blocks/ProductCard";
import { useCartStore } from "@/stores/cartStore";
import { useToast } from "@/hooks/use-toast";
import hero_products from "@/assets/hero-products.webp";

export default function Products() {
  const { t } = useTranslation(["products", "common"]);
  const { currentLanguage, isRTL } = useLanguage();
  const addItem = useCartStore((state) => state.addItem);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { data: products = [], isLoading } = useFetch("/products");
  const UPLOADS = `${import.meta.env.VITE_SERVER_URL_UPLOADS}`;

  const handleAddToCart = (product: {
    id: string;
    name: { [key: string]: string };
    image: string;
    price: number;
  }) => {
    addItem({
      id: product.id,
      name: product?.name,
      image: product.image,
      price: product.price,
    });
    toast({
      title: t("cart:addedToCart"),
      description: product?.name[currentLanguage],
      action: (
        <Button variant="outline" size="sm" onClick={() => navigate("/cart")}>
          {t("cart:viewCart")}
        </Button>
      ),
    });
  };
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <Hero
        title={t("products:hero.title")}
        subtitle={t("products:hero.subtitle")}
        imageUrl={hero_products}
      />

      {/* 2. Product Categories Grid */}
      {isLoading ? (
        <Loading />
      ) : (
        products &&
        products?.length !== 0 && (
          <Section
            title={t("products:featured.title")}
            subtitle={t("products:featured.subtitle")}
            className="bg-muted/30"
          >
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              {products?.map((item: any) => (
                <ProductCard
                  key={item.id}
                  id={item.id}
                  name={item.name[currentLanguage]}
                  price={item.price}
                  discription={item.description[currentLanguage]}
                  image={`${UPLOADS}/products/${item.imageUrl}`}
                  isRTL={isRTL}
                  onAddToCart={() =>
                    handleAddToCart({
                      id: item.id,
                      name: item.name,
                      image: `${UPLOADS}/products/${item.imageUrl}`,
                      price: item.price,
                    })
                  }
                />
              ))}
            </div>
          </Section>
        )
      )}

      {/* 3. Featured Products */}
      <AdditionalProductInfo />

      {/* 4. Product Details / Storage */}
      <Section>
        <div className="grid md:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <Card className="text-center h-full hover:shadow-lg transition-shadow border-2 hover:border-primary/30">
              <CardHeader>
                <Scale className="h-12 w-12 mx-auto mb-4 text-primary" />
                <CardTitle>{t("products:details.weights")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">500g, 1kg, 2kg, 5kg</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <Card className="text-center h-full hover:shadow-lg transition-shadow border-2 hover:border-primary/30">
              <CardHeader>
                <Snowflake className="h-12 w-12 mx-auto mb-4 text-primary" />
                <CardTitle>{t("products:details.storage")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm">
                  {t("products:details.storageText")}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Card className="text-center h-full hover:shadow-lg transition-shadow border-2 hover:border-primary/30">
              <CardHeader>
                <Package className="h-12 w-12 mx-auto mb-4 text-primary" />
                <CardTitle>{t("products:details.nutrition")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm">
                  High protein, Low fat
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </Section>

      {/* 5. Wholesale Section */}
      <Section className="bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <ShoppingCart className="h-16 w-16 mx-auto mb-6 text-primary" />
          <h2 className="text-3xl font-bold mb-4">
            {t("products:wholesale.title")}
          </h2>
          <p className="text-lg text-muted-foreground mb-6">
            {t("products:wholesale.subtitle")}
          </p>
          <Button size="lg" asChild>
            <Link to="/contact">{t("products:wholesale.cta")}</Link>
          </Button>
        </motion.div>
      </Section>

      {/* 6. FAQ Section */}
      <Section title={t("products:faq.title")}>
        <div className="max-w-3xl mx-auto space-y-4">
          {[1, 2, 3].map((item, index) => (
            <motion.div
              key={item}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="hover:shadow-md transition-shadow border-l-4 border-l-primary">
                <CardHeader>
                  <CardTitle className="text-lg">
                    {t(`products:faq.q${item}`)}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    {t(`products:faq.a${item}`)}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* 7. Dealer CTA */}
      <Section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <h2 className="text-4xl font-bold mb-4">
            {t("products:dealerCta.title")}
          </h2>
          <p className="text-xl mb-8 opacity-90">
            {t("products:dealerCta.subtitle")}
          </p>
          <Button variant="secondary" size="lg" asChild>
            <Link to="/dealers">{t("products:dealerCta.button")}</Link>
          </Button>
        </motion.div>
      </Section>
    </div>
  );
}
