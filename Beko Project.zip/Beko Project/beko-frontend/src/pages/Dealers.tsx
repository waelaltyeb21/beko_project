import { useState } from "react";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, FileText, Users, Phone, Mail } from "lucide-react";
import Benefits from "@/components/Blocks/Benefits";
import hero_dealers from "@/assets/hero-dealers.webp";

export default function Dealers() {
  const { t } = useTranslation(["dealers", "common"]);
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    businessName: "",
    ownerName: "",
    phone: "",
    email: "",
    city: "",
    experience: "",
    address: "",
    message: "",
  });

  const requirements = [
    t("dealers:requirements.req1"),
    t("dealers:requirements.req2"),
    t("dealers:requirements.req3"),
    t("dealers:requirements.req4"),
    t("dealers:requirements.req5"),
  ];

  const onboardingSteps = [
    {
      title: t("dealers:onboarding.step1.title"),
      desc: t("dealers:onboarding.step1.description"),
    },
    {
      title: t("dealers:onboarding.step2.title"),
      desc: t("dealers:onboarding.step2.description"),
    },
    {
      title: t("dealers:onboarding.step3.title"),
      desc: t("dealers:onboarding.step3.description"),
    },
    {
      title: t("dealers:onboarding.step4.title"),
      desc: t("dealers:onboarding.step4.description"),
    },
    {
      title: t("dealers:onboarding.step5.title"),
      desc: t("dealers:onboarding.step5.description"),
    },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const whatsappNumber = "249123328125";

    const text = `
طلب وكيل جديد - BEKO

اسم النشاط: ${formData.businessName}
اسم المالك: ${formData.ownerName}
الهاتف: ${formData.phone}
البريد: ${formData.email}
المدينة: ${formData.city}
سنوات الخبرة: ${formData.experience}
العنوان: ${formData.address}

ملاحظات:
${formData.message}
    `;

    const whatsappURL = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(
      text
    )}`;
    window.open(whatsappURL, "_blank");

    toast({
      title: t("dealers:application.success"),
    });

    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <Hero
        title={t("dealers:hero.title")}
        subtitle={t("dealers:hero.subtitle")}
        imageUrl={hero_dealers}
      />

      <Benefits />

      {/* 2. Requirements */}
      <Section
        title={t("dealers:requirements.title")}
        subtitle={t("dealers:requirements.subtitle")}
        className="bg-muted/30"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <Card>
            <CardContent className="p-8">
              <div className="space-y-4">
                {requirements.map((req, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-start gap-3"
                  >
                    <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-lg">{req}</span>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </Section>

      {/* 3. Application Form */}
      <Section
        title={t("dealers:application.title")}
        subtitle={t("dealers:application.subtitle")}
      >
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>اسم النشاط</Label>
                    <Input
                      required
                      value={formData.businessName}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          businessName: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>اسم المالك</Label>
                    <Input
                      required
                      value={formData.ownerName}
                      onChange={(e) =>
                        setFormData({ ...formData, ownerName: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>رقم الهاتف</Label>
                    <Input
                      required
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label>البريد الإلكتروني</Label>
                    <Input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>المدينة</Label>
                    <Input
                      required
                      value={formData.city}
                      onChange={(e) =>
                        setFormData({ ...formData, city: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label>سنوات الخبرة</Label>
                    <Input
                      type="number"
                      required
                      value={formData.experience}
                      onChange={(e) =>
                        setFormData({ ...formData, experience: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div>
                  <Label>العنوان</Label>
                  <Textarea
                    required
                    value={formData.address}
                    onChange={(e) =>
                      setFormData({ ...formData, address: e.target.value })
                    }
                  />
                </div>

                <div>
                  <Label>ملاحظات إضافية</Label>
                  <Textarea
                    value={formData.message}
                    onChange={(e) =>
                      setFormData({ ...formData, message: e.target.value })
                    }
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isSubmitting}
                >
                  <FileText className="h-5 w-5 mr-2" />
                  {isSubmitting ? "جارٍ الإرسال..." : "إرسال الطلب عبر واتساب"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* 4. Onboarding Process */}
      <Section title={t("dealers:onboarding.title")} className="bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {onboardingSteps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex gap-6 mb-8 last:mb-0"
              >
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg flex-shrink-0">
                    {index + 1}
                  </div>
                  {index < onboardingSteps.length - 1 && (
                    <div className="w-0.5 h-full bg-primary/30 my-2" />
                  )}
                </div>
                <Card className="flex-1 hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle>{step.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{step.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>

      {/* 6. Support
      <Section
        title={t("dealers:support.title")}
        subtitle={t("dealers:support.subtitle")}
        className="bg-muted/30"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <Card>
            <CardContent className="p-8">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Phone className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">
                      {t("dealers:support.phone")}
                    </h3>
                    <p className="text-muted-foreground">+249 XXX XXX XXX</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Mail className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">
                      {t("dealers:support.email")}
                    </h3>
                    <p className="text-muted-foreground">
                      dealers@beko-meat.com
                    </p>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <p className="text-sm text-muted-foreground">
                    {t("dealers:support.hours")}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </Section> */}

      {/* 7. FAQ */}
      <Section title={t("dealers:faq.title")}>
        <div className="max-w-3xl mx-auto space-y-4">
          {[1, 2, 3].map((item, index) => (
            <motion.div
              key={item}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">
                    {t(`dealers:faq.q${item}`)}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    {t(`dealers:faq.a${item}`)}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* 8. Final CTA */}
      <Section className="bg-gradient-to-br from-primary to-beko-blue-light text-primary-foreground">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <Users className="h-16 w-16 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">{t("dealers:cta.title")}</h2>
          <p className="text-xl mb-8 opacity-90">{t("dealers:cta.subtitle")}</p>
          <Button
            variant="secondary"
            size="lg"
            onClick={() => window.scrollTo({ top: 800, behavior: "smooth" })}
          >
            {t("dealers:cta.button")}
          </Button>
        </motion.div>
      </Section>
    </div>
  );
}
