import { useState } from "react";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Building,
  Facebook,
  Instagram,
  Twitter,
  Send,
  MessageSquare,
  Youtube,
} from "lucide-react";
import contact_image from "@/assets/hero-contact.webp";
import { Link } from "react-router-dom";

export default function Contact() {
  const { t } = useTranslation(["contact", "common"]);
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    await new Promise((resolve) => setTimeout(resolve, 1500));

    toast({
      title: t("contact:form.success"),
      variant: "default",
    });

    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <Hero
        title={t("contact:hero.title")}
        subtitle={t("contact:hero.subtitle")}
        imageUrl={contact_image}
      />

      {/* 1. Contact Information */}
      <Section>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: MapPin,
              title: t("contact:info.address.title"),
              value: t("contact:info.address.value"),
            },
            {
              icon: Phone,
              title: t("contact:info.phone.title"),
              value: "249914699997",
            },
            {
              icon: Mail,
              title: t("contact:info.email.title"),
              value: t("contact:info.email.value"),
            },
          ].map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="text-center h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                    <item.icon className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle>{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.value}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* 2. Contact Form */}
      <Section
        title={t("contact:form.title")}
        subtitle={t("contact:form.subtitle")}
        className="bg-muted/30"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <Card>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">{t("contact:form.name")}</Label>
                    <Input id="name" required className="mt-2" />
                  </div>
                  <div>
                    <Label htmlFor="email">{t("contact:form.email")}</Label>
                    <Input id="email" type="email" required className="mt-2" />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">{t("contact:form.phone")}</Label>
                    <Input id="phone" type="tel" required className="mt-2" />
                  </div>
                  <div>
                    <Label htmlFor="subject">{t("contact:form.subject")}</Label>
                    <Input id="subject" required className="mt-2" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="message">{t("contact:form.message")}</Label>
                  <Textarea id="message" required className="mt-2" rows={6} />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full"
                  disabled={isSubmitting}
                >
                  <Send className="h-5 w-5 mr-2" />
                  {isSubmitting ? "Sending..." : t("contact:form.submit")}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </Section>

      {/* 3. Business Contacts */}
      {/* <Section
        title={t("contact:business.title")}
        subtitle={t("contact:business.subtitle")}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <Card>
            <CardContent className="p-8">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Building className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">
                      {t("contact:business.dealerPhone")}
                    </h3>
                    <p className="text-muted-foreground">+249 XXX XXX XXX</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <Mail className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-lg mb-1">
                      {t("contact:business.dealerEmail")}
                    </h3>
                    <p className="text-muted-foreground">
                      dealers@beko-meat.com
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </Section> */}

      {/* 4. Map & Directions */}
      {/* <Section className="bg-muted/30">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-8"
        >
          <div className="aspect-video bg-muted rounded-lg overflow-hidden">
            <img
              src="/placeholder.svg"
              alt="Map"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex flex-col justify-center">
            <h2 className="text-3xl font-bold mb-4">
              {t("contact:map.title")}
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              {t("contact:map.subtitle")}
            </p>
            <Button size="lg" className="w-fit">
              <MapPin className="h-5 w-5 mr-2" />
              {t("contact:map.directions")}
            </Button>
          </div>
        </motion.div>
      </Section> */}

      {/* 5. Operating Hours */}
      <Section title={t("contact:hours.title")}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <Card className="text-center">
            <CardContent className="p-8">
              <Clock className="h-16 w-16 mx-auto mb-6 text-primary" />
              <div className="space-y-4">
                <div>
                  <h3 className="text-xl font-bold mb-2">
                    {t("contact:hours.weekdays")}
                  </h3>
                  <p className="text-2xl text-primary font-semibold">
                    {t("contact:hours.weekdaysTime")}
                  </p>
                </div>
                <div className="pt-4 border-t">
                  <h3 className="text-xl font-bold mb-2">
                    {t("contact:hours.friday")}
                  </h3>
                  <p className="text-xl text-muted-foreground">
                    {t("contact:hours.fridayTime")}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </Section>

      {/* 6. FAQ */}
      <Section title={t("contact:faq.title")} className="bg-muted/30">
        <div className="max-w-3xl mx-auto space-y-4">
          {[1, 2, 3].map((item, index) => (
            <motion.div
              key={item}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">
                    {t(`contact:faq.q${item}`)}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    {t(`contact:faq.a${item}`)}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* 7. Social Media */}
      <Section
        title={t("contact:social.title")}
        subtitle={t("contact:social.subtitle")}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="flex gap-4 justify-center"
        >
          {[
            {
              icon: Facebook,
              label: t("contact:social.facebook"),
              href: "https://www.facebook.com/share/1AUgMXeKL5/",
            },
            {
              icon: Youtube,
              label: t("contact:social.instagram"),
              href: "https://youtube.com/@beko_meat_products?si=kfGZwywtEuq_BlPN",
            },
          ].map((social, index) => (
            <motion.a
              key={index}
              href={social?.href}
              target="_blank"
              referrerPolicy="no-referrer"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.1 }}
              className="w-16 h-16 rounded-full bg-primary/10 hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-all"
              aria-label={social.label}
            >
              <social.icon className="h-8 w-8" />
            </motion.a>
          ))}
        </motion.div>
      </Section>

      {/* 8. Support Ticket CTA */}
      <Section className="bg-gradient-to-br from-primary to-beko-blue-light text-primary-foreground">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <MessageSquare className="h-16 w-16 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">
            {t("contact:support.title")}
          </h2>
          <p className="text-xl mb-8 opacity-90">
            {t("contact:support.subtitle")}
          </p>
          <Button variant="secondary" size="lg">
            <Link
              to="https://wa.me/249914699997"
              target="_blank"
              referrerPolicy="no-referrer"
            >
              {t("contact:support.ticket")}
            </Link>
          </Button>
        </motion.div>
      </Section>
    </div>
  );
}
