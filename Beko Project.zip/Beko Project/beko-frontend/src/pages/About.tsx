import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  Target,
  Eye,
  Award,
  ShieldCheck,
  Heart,
  Lightbulb,
  Factory,
  Users,
  TrendingUp,
} from "lucide-react";
import hero_about from "@/assets/hero-about.webp";
import { useLanguage } from "@/hooks/useLanguage";

export default function About() {
  const { t } = useTranslation(["about", "common"]);
  const { currentLanguage } = useLanguage();

  const values = [
    { icon: Award, title: t("about:values.quality"), color: "text-blue-600" },
    {
      icon: ShieldCheck,
      title: t("about:values.safety"),
      color: "text-green-600",
    },
    { icon: Heart, title: t("about:values.integrity"), color: "text-red-600" },
    {
      icon: Lightbulb,
      title: t("about:values.innovation"),
      color: "text-yellow-600",
    },
  ];

  const timelineData = [
    {
      id: 1,
      title: {
        ar: "التأسيس 2019",
        en: "Foundation 2019",
      },
      content: {
        ar: "انطلقت بيكو في عام 2019 من الخرطوم بطاقة إنتاجية بلغت 200 كجم يوميًا من اللحوم الحمراء وطن فراخ يوميًا، مع تركيز كامل على الجودة وبناء الثقة في السوق.",
        en: "Peco launched in 2019 from Khartoum with a production capacity of 200 kg/day of red meat and 1 ton/day of poultry, with full focus on quality and market trust.",
      },
    },
    {
      id: 2,
      title: {
        ar: "النمو والتطوير",
        en: "Growth & Development",
      },
      content: {
        ar: "شهدت هذه المرحلة توسعًا تدريجيًا في العمليات، ورفع كفاءة الإنتاج والتوزيع استجابة لزيادة الطلب، مع الحفاظ الصارم على معايير الجودة.",
        en: "This phase witnessed gradual operational expansion, enhancing production and distribution efficiency in response to growing demand while strictly maintaining quality standards.",
      },
    },
    {
      id: 3,
      title: {
        ar: "التوسع الكبير - مدينة الدامر",
        en: "Major Expansion -Ad-Damir City",
      },
      content: {
        ar: "في عام 2023 انتقلت بيكو إلى مدينة الدامر لترتفع الطاقة الإنتاجية إلى 3500 كجم لحوم حمراء يوميًا و5 أطنان فراخ يوميًا، إيذانًا بمرحلة صناعية متقدمة.",
        en: "In 2023, Peco moved to Ad-Damir City, increasing production capacity to 3500 kg/day of red meat and 5 tons/day of poultry, marking an advanced industrial stage.",
      },
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <Hero
        title={t("about:hero.title")}
        subtitle={t("about:hero.subtitle")}
        imageUrl={hero_about}
      />

      {/* 1. Our Story */}
      <Section title={t("about:story.title")}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <p className="text-lg text-muted-foreground leading-relaxed text-center">
            {t("about:story.content")}
          </p>
        </motion.div>
      </Section>

      {/* 2. Mission & Vision */}
      <Section className="bg-muted/30">
        <div className="grid md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card className="h-full hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <Target className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-2xl">
                  {t("about:mission.title")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {t("about:mission.content")}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <Card className="h-full hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <Eye className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-2xl">
                  {t("about:vision.title")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {t("about:vision.content")}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </Section>

      {/* 3. Our Values */}
      <Section title={t("about:values.title")}>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="text-center h-full hover:shadow-lg transition-all hover:scale-105">
                <CardHeader>
                  <div
                    className={`w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center`}
                  >
                    <value.icon className={`h-8 w-8 ${value.color}`} />
                  </div>
                  <CardTitle>{value.title}</CardTitle>
                </CardHeader>
              </Card>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* 4. Parent Company */}
      <Section className="bg-gradient-to-r from-primary/5 to-primary/10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center">
            <Factory className="h-10 w-10 text-primary" />
          </div>
          <h2 className="text-3xl font-bold mb-4">{t("about:parent.title")}</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            {t("about:parent.content")}
          </p>
        </motion.div>
      </Section>

      {/* 6. Team Section */}
      <Section title={t("about:team.title")} className="bg-muted/30">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <Users className="h-16 w-16 mx-auto mb-6 text-primary" />
          <p className="text-lg text-muted-foreground leading-relaxed">
            {t("about:team.content")}
          </p>
        </motion.div>
      </Section>

      {/* 7. Timeline */}
      <Section title={t("about:timeline.title")}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <div className="space-y-6">
            {timelineData.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex gap-4 items-start"
              >
                <div className="w-12 h-12 flex-shrink-0 rounded-full bg-primary/20 flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>

                <div className="flex-1 pb-6 border-b">
                  <h3 className="text-xl font-bold mb-2">
                    {item.title[currentLanguage]}
                  </h3>

                  <p className="text-muted-foreground">
                    {item.content[currentLanguage]}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </Section>

      {/* 9. CTA Section */}
      <Section className="bg-gradient-to-br from-primary via-primary to-beko-blue-dark text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center relative z-10"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            {t("about:cta.title")}
          </h2>
          <p className="text-xl md:text-2xl mb-10 opacity-90">
            {t("about:cta.content")}
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              variant="secondary"
              size="lg"
              className="shadow-strong"
              asChild
            >
              <Link to="/dealers">{t("common:cta.becomeDealer")}</Link>
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary shadow-strong"
              asChild
            >
              <Link to="/contact">{t("common:cta.contactUs")}</Link>
            </Button>
          </div>
        </motion.div>
      </Section>
    </div>
  );
}
