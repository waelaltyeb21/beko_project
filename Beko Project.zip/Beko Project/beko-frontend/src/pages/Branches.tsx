import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Hero } from "@/components/Hero";
import { Section } from "@/components/Section";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Clock } from "lucide-react";
import BranchesList from "@/components/Blocks/BranchesList";
import useFetch from "@/hooks/useFetch";
import hero_branches from "@/assets/hero-branches.webp";

export default function Branches() {
  const { t } = useTranslation(["branches", "common"]);
  const { data: branches = [], isLoading } = useFetch("/branches/all-branches");

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <Hero
        title={t("branches:hero.title")}
        subtitle={t("branches:hero.subtitle")}
        imageUrl={hero_branches}
      />

      {branches?.length > 0 && (
        <BranchesList data={branches} loading={isLoading} />
      )}

      {/* 4. Operating Hours */}
      <Section title={t("branches:hours.title")}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <Card className="text-center">
            <CardContent className="p-8">
              <Clock className="h-16 w-16 mx-auto mb-6 text-primary" />
              <div className="space-y-4">
                <div>
                  <h3 className="text-xl font-bold mb-2">
                    {t("branches:hours.weekdays")}
                  </h3>
                  <p className="text-2xl text-primary font-semibold">
                    {t("branches:hours.weekdaysTime")}
                  </p>
                </div>
                <div className="pt-4 border-t">
                  <h3 className="text-xl font-bold mb-2">
                    {t("branches:hours.friday")}
                  </h3>
                  <p className="text-xl text-muted-foreground">
                    {t("branches:hours.fridayTime")}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </Section>

      {/* 5. Distributor CTA */}
      <Section className="bg-gradient-to-br from-primary to-beko-blue-light text-primary-foreground">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <h2 className="text-4xl font-bold mb-4">
            {t("branches:distributor.title")}
          </h2>
          <p className="text-xl mb-8 opacity-90">
            {t("branches:distributor.subtitle")}
          </p>
          <Button variant="secondary" size="lg" asChild>
            <Link to="/dealers">{t("branches:distributor.button")}</Link>
          </Button>
        </motion.div>
      </Section>

      {/* 6. Request Form */}
      <Section
        title={t("branches:request.title")}
        subtitle={t("branches:request.subtitle")}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-xl mx-auto"
        >
          <Card>
            <CardContent className="p-6">
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    {t("branches:request.city")}
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder={t("branches:request.city")}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">
                    {t("branches:request.state")}
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder={t("branches:request.state")}
                  />
                </div>
                <Button type="submit" className="w-full">
                  {t("branches:request.button")}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </Section>
    </div>
  );
}
