import axios, { AxiosInstance } from "axios";
import { ENV } from "./env";

const AxiosConfig: AxiosInstance = axios.create({
  baseURL: ENV.SERVER_URL,
  withCredentials: true,
  timeout: 10000,
});

export default AxiosConfig;
