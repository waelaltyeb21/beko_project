import AxiosConfig from "@/config/AxiosConfig";
import { useEffect, useState, useCallback } from "react";
import { AxiosRequestConfig, AxiosResponse } from "axios";

interface UseFetchResult<T> {
  data: T | null;
  isLoading: boolean;
  error: string | null;
  refetch: (options?: AxiosRequestConfig) => Promise<void>;
}

const useFetch = <T = any>(url: string): UseFetchResult<T> => {
  const [data, setData] = useState<T | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const FetchData = useCallback(
    async (options: AxiosRequestConfig = {}) => {
      setIsLoading(true);
      setError(null);

      try {
        const config: AxiosRequestConfig = {
          url,
          method: "GET",
          signal: options.signal,
          ...options,
        };

        const response: AxiosResponse<T> = await AxiosConfig(config);

        if (response.status !== 200) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        setData(response.data);
        setError(null);
      } catch (err: unknown) {
        if (
          (err as any)?.name === "AbortError" ||
          (err as any)?.code === "ERR_CANCELED"
        ) {
          console.log("Request was canceled");
          return;
        }

        const message =
          (err as Error)?.message || "Could Not Fetch Data From Server!";
        setError(message);
        setData(null);
      } finally {
        setIsLoading(false);
      }
    },
    [url]
  );

  useEffect(() => {
    const controller = new AbortController();
      FetchData({ signal: controller.signal });

      return () => {
      controller.abort();
    };
  }, [url, FetchData]);

  return { data, isLoading, error, refetch: FetchData };
};

export default useFetch;
