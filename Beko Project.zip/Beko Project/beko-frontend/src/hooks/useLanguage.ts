import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import type { Language } from '@/types';

export const useLanguage = () => {
  const { i18n } = useTranslation();

  const currentLanguage = i18n.language as Language;
  const isRTL = currentLanguage === 'ar';

  useEffect(() => {
    // Update HTML attributes when language changes
    document.documentElement.lang = currentLanguage;
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
  }, [currentLanguage, isRTL]);

  const changeLanguage = (lang: Language) => {
    i18n.changeLanguage(lang);
  };

  return {
    currentLanguage,
    isRTL,
    changeLanguage,
  };
};
