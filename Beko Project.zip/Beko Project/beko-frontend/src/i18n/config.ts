import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Import translations
import commonEn from './en/common.json';
import commonAr from './ar/common.json';
import homeEn from './en/pages/home.json';
import homeAr from './ar/pages/home.json';
import aboutEn from './en/pages/about.json';
import aboutAr from './ar/pages/about.json';
import productsEn from './en/pages/products.json';
import productsAr from './ar/pages/products.json';
import branchesEn from './en/pages/branches.json';
import branchesAr from './ar/pages/branches.json';
import dealersEn from './en/pages/dealers.json';
import dealersAr from './ar/pages/dealers.json';
import newsEn from './en/pages/news.json';
import newsAr from './ar/pages/news.json';
import blogEn from './en/pages/blog.json';
import blogAr from './ar/pages/blog.json';
import cartEn from './en/pages/cart.json';
import cartAr from './ar/pages/cart.json';
import checkoutEn from './en/pages/checkout.json';
import checkoutAr from './ar/pages/checkout.json';
import contactEn from './en/pages/contact.json';
import contactAr from './ar/pages/contact.json';

const resources = {
  en: {
    common: commonEn,
    home: homeEn,
    about: aboutEn,
    products: productsEn,
    branches: branchesEn,
    dealers: dealersEn,
    news: newsEn,
    blog: blogEn,
    cart: cartEn,
    checkout: checkoutEn,
    contact: contactEn,
  },
  ar: {
    common: commonAr,
    home: homeAr,
    about: aboutAr,
    products: productsAr,
    branches: branchesAr,
    dealers: dealersAr,
    news: newsAr,
    blog: blogAr,
    cart: cartAr,
    checkout: checkoutAr,
    contact: contactAr,
  },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'ar',
    defaultNS: 'common',
    interpolation: {
      escapeValue: false,
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
    },
  });

export default i18n;
