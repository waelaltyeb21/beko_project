const { isAuthenticated } = require("../../middlewares/Auth");
const {
  Login,
  RefreshToken,
  ResetPassword,
  Logout,
} = require("../controllers/AuthController");

const AuthRoutes = require("express").Router();

const rateLimit = require("express-rate-limit");
const LoginLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 5,
  message: "Too many login attempts from this IP, please try again later.",
});

AuthRoutes.post("/login", LoginLimiter, Login);
AuthRoutes.get("/logout", Logout);
AuthRoutes.get("/refresh_token", RefreshToken);
AuthRoutes.post("/reset_password", isAuthenticated, ResetPassword);

module.exports = AuthRoutes;
