const Blog = require("../models/Blog");
const Branch = require("../models/Branch");
const Product = require("../models/Product");

const GetStatistics = async () => {
  try {
    const [totalBlogs, totalProducts, totalBranches] = await Promise.all([
      Blog.count(),
      Product.count(),
      Branch.count(),
    ]);

    const [latestBlogs, latestProducts, latestBranches] = await Promise.all([
      Blog.findAll({
        attributes: ["id", "title", "status", "createdAt"],
        order: [["createdAt", "DESC"]],
        limit: 5,
      }),
      Product.findAll({
        attributes: [
          "id",
          "name",
          "price",
          "imageUrl",
          "is_available",
          "createdAt",
        ],
        order: [["createdAt", "DESC"]],
        limit: 5,
      }),
      Branch.findAll({
        attributes: [
          "id",
          "name",
          "state",
          "city",
          "address",
          "status",
          "createdAt",
        ],
        order: [["createdAt", "DESC"]],
        limit: 5,
      }),
    ]);

    const formattedLatestBlogs = latestBlogs.map((blog) => ({
      ...blog.toJSON(),
      title: JSON.parse(blog.title),
    }));

    const formattedLatestProducts = latestProducts.map((product) => ({
      ...product.toJSON(),
      name: JSON.parse(product.name),
    }));

    const formattedLatestBranches = latestBranches.map((branch) => ({
      ...branch.toJSON(),
      name: JSON.parse(branch.name),
      city: JSON.parse(branch.city),
      address: JSON.parse(branch.address),
    }));

    return {
      totals: {
        blogs: totalBlogs,
        products: totalProducts,
        branches: totalBranches,
      },
      latest: {
        blogs: formattedLatestBlogs,
        products: formattedLatestProducts,
        branches: formattedLatestBranches,
      },
    };
  } catch (error) {
    throw new Error("Error fetching statistics: " + error.message);
  }
};

module.exports = { GetStatistics };
